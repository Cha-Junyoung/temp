#!/bin/bash

# Comprehensive Oracle E-commerce Migration Test Script
# 마이그레이션 전후 완전 비교를 위한 포괄적 테스트
# 모든 쿼리, 프로시저, 데이터 정합성 검증

BASE_URL="http://localhost:8080"
OUTPUT_FILE="comprehensive_test_results_$(date +%Y%m%d_%H%M%S).txt"
DB_HOST="localhost"
DB_PORT="1521"
DB_SID="XE"
DB_USER="ecommerce"
DB_PASS="Oracle123"

echo "=== COMPREHENSIVE MIGRATION TEST RESULTS ===" > $OUTPUT_FILE
echo "Test Date: $(date)" >> $OUTPUT_FILE
echo "Base URL: $BASE_URL" >> $OUTPUT_FILE
echo "Database: Oracle XE" >> $OUTPUT_FILE
echo "" >> $OUTPUT_FILE

# Function to test API and log results
test_api() {
    local endpoint=$1
    local description=$2
    local method=${3:-GET}
    local data=$4
    
    echo "Testing: $description" | tee -a $OUTPUT_FILE
    echo "Endpoint: $method $endpoint" >> $OUTPUT_FILE
    echo "----------------------------------------" >> $OUTPUT_FILE
    
    if [ "$method" = "POST" ]; then
        curl -s -X POST "$BASE_URL$endpoint" \
             -H "Content-Type: application/json" \
             -d "$data" >> $OUTPUT_FILE 2>&1
    elif [ "$method" = "PUT" ]; then
        curl -s -X PUT "$BASE_URL$endpoint" \
             -H "Content-Type: application/json" \
             -d "$data" >> $OUTPUT_FILE 2>&1
    elif [ "$method" = "DELETE" ]; then
        curl -s -X DELETE "$BASE_URL$endpoint" >> $OUTPUT_FILE 2>&1
    else
        curl -s "$BASE_URL$endpoint" >> $OUTPUT_FILE 2>&1
    fi
    
    echo "" >> $OUTPUT_FILE
    echo "" >> $OUTPUT_FILE
}

# Function to execute SQL and log results
test_sql() {
    local sql_query=$1
    local description=$2
    
    echo "SQL Test: $description" | tee -a $OUTPUT_FILE
    echo "Query: $sql_query" >> $OUTPUT_FILE
    echo "----------------------------------------" >> $OUTPUT_FILE
    
    # Execute SQL using sqlplus (requires Oracle client)
    echo "$sql_query" | sqlplus -s $DB_USER/$DB_PASS@$DB_HOST:$DB_PORT/$DB_SID >> $OUTPUT_FILE 2>&1
    
    echo "" >> $OUTPUT_FILE
    echo "" >> $OUTPUT_FILE
}

echo "Starting COMPREHENSIVE migration test..."

# ===== 1. HEALTH AND CONNECTIVITY =====
echo "=== 1. HEALTH AND CONNECTIVITY ===" >> $OUTPUT_FILE
test_api "/api/health" "Application Health Check"

# ===== 2. USER MANAGEMENT TESTS =====
echo "=== 2. USER MANAGEMENT TESTS ===" >> $OUTPUT_FILE

# Basic CRUD operations
test_api "/api/users" "Get All Users"
test_api "/api/users/1" "Get User by ID"
test_api "/api/users/search?keyword=admin" "Search Users"

# Create test user
test_api "/api/users" "Create Test User" "POST" '{
    "username": "migration_test_user",
    "email": "migration_test@example.com",
    "password": "TestPass123!",
    "firstName": "Migration",
    "lastName": "Test",
    "phoneNumber": "555-0123",
    "gender": "M",
    "createdBy": 1
}'

# Update operations
test_api "/api/users/1" "Update User" "PUT" '{
    "firstName": "Updated",
    "lastName": "Name",
    "phoneNumber": "555-9999"
}'

# User statistics and reports
test_api "/api/users/statistics" "User Statistics"
test_api "/api/users/active" "Active Users"
test_api "/api/users/by-status/ACTIVE" "Users by Status"

# ===== 3. PRODUCT MANAGEMENT TESTS =====
echo "=== 3. PRODUCT MANAGEMENT TESTS ===" >> $OUTPUT_FILE

# Basic product operations
test_api "/api/products" "Get All Products"
test_api "/api/products/1" "Get Product by ID"
test_api "/api/products/search?keyword=laptop" "Search Products"
test_api "/api/products/category/1" "Products by Category"
test_api "/api/products/brand/1" "Products by Brand"

# Stock and inventory
test_api "/api/products/low-stock" "Low Stock Products"
test_api "/api/products/out-of-stock" "Out of Stock Products"
test_api "/api/products/featured" "Featured Products"
test_api "/api/products/top-selling?limit=10" "Top Selling Products"

# Create test product
test_api "/api/products" "Create Test Product" "POST" '{
    "productName": "Migration Test Product",
    "description": "Test product for migration validation",
    "sku": "MIG-TEST-001",
    "categoryId": 1,
    "brandId": 1,
    "price": 99.99,
    "costPrice": 50.00,
    "stockQuantity": 100,
    "minStockLevel": 10,
    "maxStockLevel": 500,
    "weight": 1.5,
    "createdBy": 1
}'

# Product reports
test_api "/api/products/sales-report?startDate=2024-01-01&endDate=2024-12-31" "Product Sales Report"
test_api "/api/products/inventory-report" "Inventory Report"

# ===== 4. ORDER MANAGEMENT TESTS =====
echo "=== 4. ORDER MANAGEMENT TESTS ===" >> $OUTPUT_FILE

# Order operations
test_api "/api/orders" "Get All Orders"
test_api "/api/orders/1" "Get Order by ID"
test_api "/api/orders/user/1" "Orders by User"
test_api "/api/orders/status/PENDING" "Orders by Status"
test_api "/api/orders/recent?days=30" "Recent Orders"

# Create test order
test_api "/api/orders" "Create Test Order" "POST" '{
    "userId": 1,
    "totalAmount": 199.98,
    "discountAmount": 0.00,
    "taxAmount": 16.00,
    "shippingAmount": 9.99,
    "finalAmount": 225.97,
    "notes": "Migration test order",
    "createdBy": 1
}'

# Order reports
test_api "/api/orders/summary-report?startDate=2024-01-01&endDate=2024-12-31" "Order Summary Report"
test_api "/api/orders/daily-sales?startDate=2024-01-01&endDate=2024-12-31" "Daily Sales Report"
test_api "/api/orders/top-customers?limit=10" "Top Customers Report"

# ===== 5. PAYMENT TESTS =====
echo "=== 5. PAYMENT TESTS ===" >> $OUTPUT_FILE

test_api "/api/payments" "Get All Payments"
test_api "/api/payments/order/1" "Payments by Order"
test_api "/api/payments/status/COMPLETED" "Payments by Status"

# Create test payment
test_api "/api/payments" "Create Test Payment" "POST" '{
    "orderId": 1,
    "amount": 225.97,
    "paymentMethodId": 1,
    "paymentStatus": "PENDING",
    "createdBy": 1
}'

# ===== 6. REVIEW TESTS =====
echo "=== 6. REVIEW TESTS ===" >> $OUTPUT_FILE

test_api "/api/reviews" "Get All Reviews"
test_api "/api/reviews/product/1" "Reviews by Product"
test_api "/api/reviews/user/1" "Reviews by User"
test_api "/api/reviews/rating/5" "Reviews by Rating"
test_api "/api/reviews/pending" "Pending Reviews"

# Create test review
test_api "/api/reviews" "Create Test Review" "POST" '{
    "productId": 1,
    "userId": 1,
    "rating": 5,
    "reviewComment": "Excellent product! Migration test review.",
    "createdBy": 1
}'

# Review analytics
test_api "/api/reviews/analytics?startDate=2024-01-01&endDate=2024-12-31" "Review Analytics"
test_api "/api/reviews/top-reviewed?limit=10" "Top Reviewed Products"

# ===== 7. INVENTORY TESTS =====
echo "=== 7. INVENTORY TESTS ===" >> $OUTPUT_FILE

test_api "/api/inventory" "Get All Inventory"
test_api "/api/inventory/product/1" "Inventory by Product"
test_api "/api/inventory/warehouse/1" "Inventory by Warehouse"
test_api "/api/inventory/movements" "Inventory Movements"

# ===== 8. ANALYTICS TESTS =====
echo "=== 8. ANALYTICS TESTS ===" >> $OUTPUT_FILE

test_api "/api/analytics/sales-summary" "Sales Summary Analytics"
test_api "/api/analytics/product-performance" "Product Performance Analytics"
test_api "/api/analytics/customer-segments" "Customer Segmentation Analytics"

# ===== 9. DATABASE DIRECT TESTS =====
echo "=== 9. DATABASE DIRECT TESTS ===" >> $OUTPUT_FILE

# Table counts for data integrity
test_sql "SELECT COUNT(*) as USER_COUNT FROM USERS;" "User Table Count"
test_sql "SELECT COUNT(*) as PRODUCT_COUNT FROM PRODUCTS;" "Product Table Count"
test_sql "SELECT COUNT(*) as ORDER_COUNT FROM ORDERS;" "Order Table Count"
test_sql "SELECT COUNT(*) as PAYMENT_COUNT FROM PAYMENTS;" "Payment Table Count"
test_sql "SELECT COUNT(*) as REVIEW_COUNT FROM REVIEWS;" "Review Table Count"

# Complex queries
test_sql "SELECT u.STATUS, COUNT(*) as COUNT FROM USERS u GROUP BY u.STATUS;" "User Status Distribution"
test_sql "SELECT p.STATUS, COUNT(*) as COUNT FROM PRODUCTS p GROUP BY p.STATUS;" "Product Status Distribution"
test_sql "SELECT o.ORDER_STATUS, COUNT(*) as COUNT FROM ORDERS o GROUP BY o.ORDER_STATUS;" "Order Status Distribution"

# Join queries
test_sql "SELECT COUNT(*) FROM ORDERS o JOIN USERS u ON o.USER_ID = u.USER_ID WHERE u.STATUS = 'ACTIVE';" "Active User Orders"
test_sql "SELECT COUNT(*) FROM ORDER_ITEMS oi JOIN PRODUCTS p ON oi.PRODUCT_ID = p.PRODUCT_ID WHERE p.STATUS = 'ACTIVE';" "Active Product Orders"

# Aggregate functions
test_sql "SELECT AVG(FINAL_AMOUNT) as AVG_ORDER_VALUE FROM ORDERS WHERE ORDER_STATUS = 'COMPLETED';" "Average Order Value"
test_sql "SELECT SUM(FINAL_AMOUNT) as TOTAL_REVENUE FROM ORDERS WHERE ORDER_STATUS = 'COMPLETED';" "Total Revenue"
test_sql "SELECT AVG(RATING) as AVG_RATING FROM REVIEWS WHERE STATUS = 'APPROVED';" "Average Product Rating"

# Window functions
test_sql "SELECT PRODUCT_ID, PRICE, ROW_NUMBER() OVER (ORDER BY PRICE DESC) as PRICE_RANK FROM PRODUCTS WHERE STATUS = 'ACTIVE' AND ROWNUM <= 10;" "Product Price Ranking"

# Date functions
test_sql "SELECT COUNT(*) FROM ORDERS WHERE ORDER_DATE >= SYSDATE - 30;" "Orders Last 30 Days"
test_sql "SELECT TO_CHAR(ORDER_DATE, 'YYYY-MM') as MONTH, COUNT(*) FROM ORDERS GROUP BY TO_CHAR(ORDER_DATE, 'YYYY-MM') ORDER BY MONTH;" "Orders by Month"

# ===== 10. STORED PROCEDURE TESTS =====
echo "=== 10. STORED PROCEDURE TESTS ===" >> $OUTPUT_FILE

# User procedures
test_sql "BEGIN USER_MAINTENANCE_PROC(1); END;" "User Maintenance Procedure"
test_sql "BEGIN USER_REPORT_PROC('MONTHLY', '2024-01-01'); END;" "User Report Procedure"

# Inventory procedures
test_sql "BEGIN INVENTORY_UPDATE_PROC(1, 10); END;" "Inventory Update Procedure"
test_sql "BEGIN INVENTORY_REORDER_PROC(1); END;" "Inventory Reorder Procedure"

# Order procedures
test_sql "BEGIN ORDER_PROCESSING_PROC(1); END;" "Order Processing Procedure"

# Payment procedures
test_sql "BEGIN PAYMENT_PROCESSING_PROC(1); END;" "Payment Processing Procedure"

# Review procedures
test_sql "BEGIN REVIEW_MODERATION_PROC(1); END;" "Review Moderation Procedure"

# Analytics procedures
test_sql "BEGIN ANALYTICS_REFRESH_PROC('DAILY_SALES'); END;" "Analytics Refresh Procedure"
test_sql "BEGIN DATA_MINING_PROC('CUSTOMER_SEGMENTATION', 'default'); END;" "Data Mining Procedure"

# ===== 11. SEQUENCE TESTS =====
echo "=== 11. SEQUENCE TESTS ===" >> $OUTPUT_FILE

test_sql "SELECT USER_SEQ.NEXTVAL FROM DUAL;" "User Sequence Test"
test_sql "SELECT PRODUCT_SEQ.NEXTVAL FROM DUAL;" "Product Sequence Test"
test_sql "SELECT ORDER_SEQ.NEXTVAL FROM DUAL;" "Order Sequence Test"

# ===== 12. CONSTRAINT AND INDEX TESTS =====
echo "=== 12. CONSTRAINT AND INDEX TESTS ===" >> $OUTPUT_FILE

test_sql "SELECT COUNT(*) FROM USER_CONSTRAINTS WHERE TABLE_NAME LIKE '%USERS%';" "User Table Constraints"
test_sql "SELECT COUNT(*) FROM USER_INDEXES WHERE TABLE_NAME LIKE '%PRODUCTS%';" "Product Table Indexes"

# ===== 13. PERFORMANCE TESTS =====
echo "=== 13. PERFORMANCE TESTS ===" >> $OUTPUT_FILE

# Large dataset queries
test_sql "SELECT COUNT(*) FROM (SELECT * FROM PRODUCTS WHERE ROWNUM <= 1000);" "Large Product Query"
test_sql "SELECT COUNT(*) FROM (SELECT o.*, u.USERNAME FROM ORDERS o JOIN USERS u ON o.USER_ID = u.USER_ID WHERE ROWNUM <= 1000);" "Large Join Query"

# ===== 14. ERROR HANDLING TESTS =====
echo "=== 14. ERROR HANDLING TESTS ===" >> $OUTPUT_FILE

test_api "/api/users/99999" "Non-existent User"
test_api "/api/products/99999" "Non-existent Product"
test_api "/api/orders/99999" "Non-existent Order"

# Invalid data tests
test_api "/api/users" "Invalid User Creation" "POST" '{
    "username": "",
    "email": "invalid-email",
    "password": "123"
}'

# ===== FINAL SUMMARY =====
echo "=== FINAL TEST SUMMARY ===" >> $OUTPUT_FILE
echo "Total API tests: $(grep -c "Testing:" $OUTPUT_FILE)" >> $OUTPUT_FILE
echo "Total SQL tests: $(grep -c "SQL Test:" $OUTPUT_FILE)" >> $OUTPUT_FILE
echo "Test completed at: $(date)" >> $OUTPUT_FILE

echo "COMPREHENSIVE migration test completed!"
echo "Results saved to: $OUTPUT_FILE"
echo "Total tests executed: $(grep -c -E "(Testing:|SQL Test:)" $OUTPUT_FILE)"