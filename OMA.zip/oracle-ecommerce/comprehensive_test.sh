#!/bin/bash

# =================================================================
# Oracle E-commerce Migration 포괄적 테스트 스크립트
# 모든 API, 데이터베이스 테이블, 저장 프로시저 테스트
# =================================================================

BASE_URL="http://localhost:8080"
OUTPUT_FILE="comprehensive_test_results_$(date +%Y%m%d_%H%M%S).txt"

# Database connection info (foSCENARIO_USER_DATA='{
    "username": "scenariouser",
    "email": "scenario@test.com",
    "password": "ScenarioPass123!",
    "firstName": "Scenario",
    "lastName": "Test",
    "phoneNumber": "010-9999-8888",
    "birthDate": "1995-05-15T00:00:00",
    "gender": "F",
    "status": "ACTIVE"
}'QL testing)
DB_HOST="localhost"
DB_PORT="1521"
DB_SID="XE"
DB_USER="system"
DB_PASS="Oracle123"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo "==================================================================" | tee $OUTPUT_FILE
echo "Oracle E-commerce Migration 포괄적 테스트 결과" | tee -a $OUTPUT_FILE
echo "==================================================================" | tee -a $OUTPUT_FILE
echo "테스트 시작 시간: $(date)" | tee -a $OUTPUT_FILE
echo "Base URL: $BASE_URL" | tee -a $OUTPUT_FILE
echo "Database: Oracle XE ($DB_HOST:$DB_PORT/$DB_SID)" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

# =================================================================
# 유틸리티 함수들
# =================================================================

# API 테스트 함수
test_api() {
    local endpoint=$1
    local description=$2
    local method=${3:-GET}
    local data=$4
    local expected_status=${5:-200}
    
    echo -e "${BLUE}[API TEST]${NC} $description" | tee -a $OUTPUT_FILE
    echo "Endpoint: $method $endpoint" >> $OUTPUT_FILE
    echo "Expected Status: $expected_status" >> $OUTPUT_FILE
    echo "----------------------------------------" >> $OUTPUT_FILE
    
    local response
    local status_code
    
    if [ "$method" = "POST" ]; then
        response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL$endpoint" \
                   -H "Content-Type: application/json" \
                   -d "$data" 2>/dev/null)
    elif [ "$method" = "PUT" ]; then
        response=$(curl -s -w "\n%{http_code}" -X PUT "$BASE_URL$endpoint" \
                   -H "Content-Type: application/json" \
                   -d "$data" 2>/dev/null)
    elif [ "$method" = "DELETE" ]; then
        response=$(curl -s -w "\n%{http_code}" -X DELETE "$BASE_URL$endpoint" 2>/dev/null)
    else
        response=$(curl -s -w "\n%{http_code}" "$BASE_URL$endpoint" 2>/dev/null)
    fi
    
    status_code=$(echo "$response" | tail -n1)
    response_body=$(echo "$response" | head -n -1)
    
    echo "Status Code: $status_code" >> $OUTPUT_FILE
    echo "Response Body:" >> $OUTPUT_FILE
    echo "$response_body" >> $OUTPUT_FILE
    
    if [ "$status_code" = "$expected_status" ]; then
        echo -e "${GREEN}✓ PASS${NC} - Status: $status_code" | tee -a $OUTPUT_FILE
    else
        echo -e "${RED}✗ FAIL${NC} - Expected: $expected_status, Got: $status_code" | tee -a $OUTPUT_FILE
    fi
    
    echo "" >> $OUTPUT_FILE
    echo "" >> $OUTPUT_FILE
}

# SQL 테스트 함수 (sqlplus가 있는 경우에만)
test_sql() {
    local sql=$1
    local description=$2
    
    echo -e "${YELLOW}[SQL TEST]${NC} $description" | tee -a $OUTPUT_FILE
    echo "SQL: $sql" >> $OUTPUT_FILE
    echo "----------------------------------------" >> $OUTPUT_FILE
    
    if command -v sqlplus >/dev/null 2>&1; then
        local result=$(echo "SET PAGESIZE 0; SET FEEDBACK OFF; SET HEADING OFF; $sql; EXIT;" | \
                      sqlplus -S "$DB_USER/$DB_PASS@$DB_HOST:$DB_PORT/$DB_SID" 2>&1)
        
        if [[ $result == *"ERROR"* ]] || [[ $result == *"ORA-"* ]]; then
            echo -e "${RED}✗ SQL ERROR${NC}" | tee -a $OUTPUT_FILE
            echo "$result" >> $OUTPUT_FILE
        else
            echo -e "${GREEN}✓ SQL SUCCESS${NC}" | tee -a $OUTPUT_FILE
            echo "Result: $result" >> $OUTPUT_FILE
        fi
    else
        echo -e "${YELLOW}⚠ SKIP${NC} - sqlplus not available" | tee -a $OUTPUT_FILE
    fi
    
    echo "" >> $OUTPUT_FILE
    echo "" >> $OUTPUT_FILE
}

# 프로시저 테스트 함수
test_procedure() {
    local proc_call=$1
    local description=$2
    
    echo -e "${YELLOW}[PROCEDURE TEST]${NC} $description" | tee -a $OUTPUT_FILE
    echo "Procedure Call: $proc_call" >> $OUTPUT_FILE
    echo "----------------------------------------" >> $OUTPUT_FILE
    
    if command -v sqlplus >/dev/null 2>&1; then
        local result=$(echo "SET SERVEROUTPUT ON; $proc_call; EXIT;" | \
                      sqlplus -S "$DB_USER/$DB_PASS@$DB_HOST:$DB_PORT/$DB_SID" 2>&1)
        
        if [[ $result == *"ERROR"* ]] || [[ $result == *"ORA-"* ]]; then
            echo -e "${RED}✗ PROCEDURE ERROR${NC}" | tee -a $OUTPUT_FILE
            echo "$result" >> $OUTPUT_FILE
        else
            echo -e "${GREEN}✓ PROCEDURE SUCCESS${NC}" | tee -a $OUTPUT_FILE
            echo "Result: $result" >> $OUTPUT_FILE
        fi
    else
        echo -e "${YELLOW}⚠ SKIP${NC} - sqlplus not available" | tee -a $OUTPUT_FILE
    fi
    
    echo "" >> $OUTPUT_FILE
    echo "" >> $OUTPUT_FILE
}

# =================================================================
# 1. 시스템 헬스 체크
# =================================================================

echo -e "${BLUE}=== 1. 시스템 헬스 체크 ===${NC}" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

test_api "/health" "애플리케이션 헬스 체크"
test_api "/api/health" "API 헬스 체크"
test_api "/actuator/health" "Actuator 헬스 체크" "GET" "" "404"

# =================================================================
# 2. 사용자(User) 관리 테스트
# =================================================================

echo -e "${BLUE}=== 2. 사용자(User) 관리 테스트 ===${NC}" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

# 사용자 생성 테스트
USER_DATA='{
    "username": "testuser2024",
    "email": "test@oracle.com",
    "password": "TestPass123!",
    "firstName": "Test",
    "lastName": "User",
    "phoneNumber": "010-1234-5678",
    "birthDate": "1990-01-01T00:00:00",
    "gender": "M",
    "status": "ACTIVE"
}'

test_api "/api/users" "사용자 생성" "POST" "$USER_DATA"

# 사용자 조회 테스트
test_api "/api/users" "전체 사용자 조회"
test_api "/api/users/1" "특정 사용자 조회"
test_api "/api/users/search?keyword=test" "사용자 검색"
test_api "/api/users/statistics" "사용자 통계"

# 사용자 수정 테스트
UPDATE_USER_DATA='{
    "firstName": "Updated",
    "lastName": "User",
    "phoneNumber": "010-9876-5432"
}'

test_api "/api/users/1" "사용자 정보 수정" "PUT" "$UPDATE_USER_DATA"
test_api "/api/users/1/status?status=INACTIVE" "사용자 상태 변경" "PUT"

# 사용자 유지보수 프로시저 테스트
test_api "/api/users/1/maintenance" "사용자 유지보수" "POST"

# =================================================================
# 3. 상품(Product) 관리 테스트
# =================================================================

echo -e "${BLUE}=== 3. 상품(Product) 관리 테스트 ===${NC}" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

# 상품 생성 테스트
PRODUCT_DATA='{
    "productName": "Oracle Test Product",
    "description": "Oracle 마이그레이션 테스트용 상품",
    "sku": "ORA-TEST-001",
    "categoryId": 1,
    "brandId": 1,
    "price": 99.99,
    "costPrice": 59.99,
    "status": "ACTIVE",
    "stockQuantity": 100,
    "minStockLevel": 10,
    "maxStockLevel": 1000,
    "weight": 1.5,
    "dimensions": "10x10x10"
}'

test_api "/api/products" "상품 생성" "POST" "$PRODUCT_DATA"

# 상품 조회 테스트
test_api "/api/products" "전체 상품 조회"
test_api "/api/products/101" "특정 상품 조회"
test_api "/api/products/search?keyword=Oracle" "상품 검색"
test_api "/api/products/low-stock" "재고 부족 상품 조회"
test_api "/api/products/top-selling?limit=5" "인기 상품 조회"

# 상품 보고서 테스트
test_api "/api/products/sales-report?startDate=2024-01-01&endDate=2024-12-31" "상품 판매 보고서"
test_api "/api/products/inventory-report" "재고 보고서"

# 상품 수정 테스트
UPDATE_PRODUCT_DATA='{
    "productName": "Updated Oracle Product",
    "price": 109.99,
    "description": "업데이트된 Oracle 테스트 상품"
}'

test_api "/api/products/101" "상품 정보 수정" "PUT" "$UPDATE_PRODUCT_DATA"
test_api "/api/products/101/stock?quantity=50" "상품 재고 수정" "PUT"
test_api "/api/products/101/price?price=119.99" "상품 가격 수정" "PUT"

# 상품 관련 프로시저 테스트
test_api "/api/products/101/inventory-update?quantity=25" "재고 업데이트 프로시저" "POST"
test_api "/api/products/category/1/price-update?percentage=10" "카테고리별 가격 업데이트" "POST"

# =================================================================
# 4. 데이터베이스 직접 테스트 (sqlplus 사용 가능시)
# =================================================================

echo -e "${BLUE}=== 4. 데이터베이스 직접 테스트 ===${NC}" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

# 테이블 존재 확인
test_sql "SELECT COUNT(*) FROM USER_TABLES WHERE TABLE_NAME IN ('USERS', 'PRODUCTS', 'ORDERS')" "주요 테이블 존재 확인"

# 시퀀스 확인
test_sql "SELECT COUNT(*) FROM USER_SEQUENCES WHERE SEQUENCE_NAME LIKE '%_SEQ'" "시퀀스 확인"

# 데이터 무결성 테스트
test_sql "SELECT COUNT(*) FROM USERS WHERE STATUS NOT IN ('ACTIVE', 'INACTIVE', 'DELETED')" "사용자 상태 무결성 확인"
test_sql "SELECT COUNT(*) FROM PRODUCTS WHERE PRICE < 0 OR STOCK_QUANTITY < 0" "상품 데이터 무결성 확인"

# 복잡한 조인 쿼리 테스트
test_sql "SELECT COUNT(*) FROM USERS u LEFT JOIN ORDERS o ON u.USER_ID = o.USER_ID" "사용자-주문 조인 테스트"
test_sql "SELECT COUNT(*) FROM PRODUCTS p LEFT JOIN CATEGORIES c ON p.CATEGORY_ID = c.CATEGORY_ID" "상품-카테고리 조인 테스트"

# 집계 함수 테스트
test_sql "SELECT COUNT(*) as USER_COUNT, AVG(CASE WHEN BIRTH_DATE IS NOT NULL THEN MONTHS_BETWEEN(SYSDATE, BIRTH_DATE)/12 ELSE NULL END) as AVG_AGE FROM USERS WHERE STATUS = 'ACTIVE'" "사용자 통계"
test_sql "SELECT COUNT(*) as PRODUCT_COUNT, AVG(PRICE) as AVG_PRICE, SUM(STOCK_QUANTITY) as TOTAL_STOCK FROM PRODUCTS WHERE STATUS = 'ACTIVE'" "상품 통계"

# =================================================================
# 5. 저장 프로시저 테스트
# =================================================================

echo -e "${BLUE}=== 5. 저장 프로시저 테스트 ===${NC}" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

# 사용자 유지보수 프로시저
test_procedure "BEGIN USER_MAINTENANCE_PROC(1); END;" "사용자 유지보수 프로시저"

# 재고 업데이트 프로시저
test_procedure "BEGIN INVENTORY_UPDATE_PROC(1, 10); END;" "재고 업데이트 프로시저"

# 가격 업데이트 프로시저
test_procedure "BEGIN PRICE_UPDATE_PROC(1, 5); END;" "카테고리별 가격 업데이트 프로시저"

# 사용자 보고서 프로시저
test_procedure "BEGIN USER_REPORT_PROC('MONTHLY', '2024-01-01'); END;" "사용자 보고서 프로시저"

# =================================================================
# 6. 성능 테스트
# =================================================================

echo -e "${BLUE}=== 6. 성능 테스트 ===${NC}" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

# 대량 데이터 조회 테스트
test_sql "SELECT COUNT(*) FROM (SELECT * FROM USERS WHERE ROWNUM <= 1000)" "대량 사용자 데이터 조회"
test_sql "SELECT COUNT(*) FROM (SELECT * FROM PRODUCTS WHERE ROWNUM <= 1000)" "대량 상품 데이터 조회"

# 복잡한 집계 쿼리 성능 테스트
test_sql "SELECT COUNT(*) FROM (SELECT u.USER_ID, COUNT(o.ORDER_ID) as order_count FROM USERS u LEFT JOIN ORDERS o ON u.USER_ID = o.USER_ID GROUP BY u.USER_ID)" "복잡한 집계 쿼리 성능"

# 인덱스 활용 테스트
test_sql "SELECT COUNT(*) FROM USERS WHERE USERNAME = 'testuser2024'" "인덱스 활용 조회 테스트"
test_sql "SELECT COUNT(*) FROM PRODUCTS WHERE SKU = 'ORA-TEST-001'" "SKU 인덱스 활용 테스트"

# =================================================================
# 7. 오류 처리 테스트
# =================================================================

echo -e "${BLUE}=== 7. 오류 처리 테스트 ===${NC}" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

# 존재하지 않는 리소스 테스트
test_api "/api/users/99999" "존재하지 않는 사용자 조회" "GET" "" "404"
test_api "/api/products/99999" "존재하지 않는 상품 조회" "GET" "" "404"

# 잘못된 데이터 형식 테스트
INVALID_USER_DATA='{
    "username": "",
    "email": "invalid-email",
    "password": "123"
}'

test_api "/api/users" "잘못된 사용자 데이터 생성" "POST" "$INVALID_USER_DATA" "400"

INVALID_PRODUCT_DATA='{
    "productName": "",
    "price": -10,
    "stockQuantity": -5
}'

test_api "/api/products" "잘못된 상품 데이터 생성" "POST" "$INVALID_PRODUCT_DATA" "400"

# 잘못된 SQL 테스트
test_sql "SELECT * FROM NON_EXISTENT_TABLE" "존재하지 않는 테이블 조회"
test_procedure "BEGIN NON_EXISTENT_PROC(); END;" "존재하지 않는 프로시저 호출"

# =================================================================
# 8. 보안 테스트
# =================================================================

echo -e "${BLUE}=== 8. 보안 테스트 ===${NC}" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

# SQL 인젝션 테스트
test_api "/api/users/search?keyword=test" "SQL 인젝션 방어 확인"
test_api "/api/products/search?keyword=product" "XSS 방어 확인"

# 잘못된 파라미터 테스트
test_api "/api/users/abc" "잘못된 ID 형식 테스트" "GET" "" "400"
test_api "/api/products/abc/stock?quantity=abc" "잘못된 숫자 형식 테스트" "PUT" "" "400"

# =================================================================
# 9. 통합 시나리오 테스트
# =================================================================

echo -e "${BLUE}=== 9. 통합 시나리오 테스트 ===${NC}" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

# 전체 사용자 라이프사이클 테스트
SCENARIO_USER_DATA='{
    "username": "scenario_user",
    "email": "scenario@test.com",
    "password": "ScenarioPass123!",
    "firstName": "Scenario",
    "lastName": "Test",
    "phoneNumber": "010-1111-2222",
    "birthDate": "1985-05-15",
    "gender": "F"
}'

test_api "/api/users" "시나리오: 사용자 생성" "POST" "$SCENARIO_USER_DATA"
test_api "/api/users/search?keyword=scenario" "시나리오: 생성된 사용자 검색"

# 전체 상품 라이프사이클 테스트
SCENARIO_PRODUCT_DATA='{
    "productName": "Scenario Test Product",
    "description": "시나리오 테스트용 상품",
    "sku": "SCENARIO-001",
    "categoryId": 1,
    "brandId": 1,
    "price": 199.99,
    "costPrice": 120.00,
    "status": "ACTIVE",
    "stockQuantity": 50,
    "minStockLevel": 5,
    "maxStockLevel": 500
}'

test_api "/api/products" "시나리오: 상품 생성" "POST" "$SCENARIO_PRODUCT_DATA"
test_api "/api/products/search?keyword=Scenario" "시나리오: 생성된 상품 검색"

# =================================================================
# 10. 정리 및 요약
# =================================================================

echo -e "${BLUE}=== 10. 테스트 완료 및 요약 ===${NC}" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

echo "테스트 완료 시간: $(date)" | tee -a $OUTPUT_FILE
echo "" | tee -a $OUTPUT_FILE

# 결과 파일에서 성공/실패 통계 계산
TOTAL_TESTS=$(grep -c "✓ PASS\|✗ FAIL\|⚠ SKIP" $OUTPUT_FILE || echo "0")
PASSED_TESTS=$(grep -c "✓ PASS" $OUTPUT_FILE || echo "0")
FAILED_TESTS=$(grep -c "✗ FAIL" $OUTPUT_FILE || echo "0")
SKIPPED_TESTS=$(grep -c "⚠ SKIP" $OUTPUT_FILE || echo "0")

echo "==================================================================" | tee -a $OUTPUT_FILE
echo "테스트 결과 요약:" | tee -a $OUTPUT_FILE
echo "  전체 테스트: $TOTAL_TESTS" | tee -a $OUTPUT_FILE
echo "  성공: $PASSED_TESTS" | tee -a $OUTPUT_FILE
echo "  실패: $FAILED_TESTS" | tee -a $OUTPUT_FILE
echo "  건너뜀: $SKIPPED_TESTS" | tee -a $OUTPUT_FILE
echo "==================================================================" | tee -a $OUTPUT_FILE

if [ $FAILED_TESTS -eq 0 ]; then
    echo -e "${GREEN}🎉 모든 테스트가 성공적으로 완료되었습니다!${NC}"
else
    echo -e "${RED}⚠️  $FAILED_TESTS 개의 테스트가 실패했습니다. 로그를 확인해주세요.${NC}"
fi

echo ""
echo "상세 결과는 $OUTPUT_FILE 파일을 확인하세요."
echo ""

# 파일 권한 설정 (Windows에서는 무시됨)
chmod 644 $OUTPUT_FILE 2>/dev/null || true

exit 0