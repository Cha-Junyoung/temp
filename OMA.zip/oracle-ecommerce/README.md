# Oracle E-commerce System

Oracle 데이터베이스를 사용하는 복잡한 전자상거래 시스템입니다. 이 프로젝트는 Oracle에서 다른 DBMS로의 마이그레이션 POC를 위해 설계되었습니다.

## 프로젝트 특징

### 데이터베이스 구조
- **42개의 테이블**: 사용자, 상품, 주문, 결제, 재고, 리뷰, 분석 등 복잡한 비즈니스 도메인 커버
- **복잡한 관계**: 외래키, 인덱스, 제약조건을 통한 데이터 무결성 보장
- **10개의 복잡한 저장 프로시저**: 비즈니스 로직 처리 및 데이터 분석

### MyBatis 매퍼
- **100개 이상의 SQL 쿼리**: 다양한 복잡도의 SQL 문 포함
- **복잡한 조인 쿼리**: 다중 테이블 조인 및 서브쿼리 활용
- **분석 쿼리**: 윈도우 함수, 집계 함수, CTE 등 고급 SQL 기능 사용
- **프로시저 호출**: Oracle 저장 프로시저 호출 예제

### 기술 스택
- **Spring Boot 3.2.0**: 최신 스프링 부트 프레임워크
- **MyBatis 3.0.3**: SQL 매퍼 프레임워크
- **Oracle Database**: 오라클 데이터베이스 (ojdbc11)
- **Java 17**: 최신 LTS 자바 버전

## 프로젝트 구조

```
oracle-ecommerce/
├── src/main/java/com/oracle/ecommerce/
│   ├── config/          # 설정 클래스
│   ├── controller/      # REST 컨트롤러
│   ├── service/         # 비즈니스 로직 서비스
│   ├── mapper/          # MyBatis 매퍼 인터페이스
│   ├── model/           # 엔티티 모델 클래스
│   └── dto/             # 데이터 전송 객체
├── src/main/resources/
│   ├── mapper/          # MyBatis XML 매퍼 파일
│   │   ├── user/        # 사용자 관련 매퍼
│   │   ├── product/     # 상품 관련 매퍼
│   │   ├── order/       # 주문 관련 매퍼
│   │   ├── payment/     # 결제 관련 매퍼
│   │   ├── inventory/   # 재고 관련 매퍼
│   │   ├── review/      # 리뷰 관련 매퍼
│   │   └── analytics/   # 분석 관련 매퍼
│   ├── schema.sql       # 데이터베이스 스키마
│   ├── procedures.sql   # 저장 프로시저
│   └── application.yml  # 애플리케이션 설정
└── pom.xml              # Maven 의존성 설정
```

## 데이터베이스 테이블 (42개)

### 핵심 비즈니스 테이블
1. **USERS** - 사용자 정보
2. **USER_PROFILES** - 사용자 프로필
3. **USER_SESSIONS** - 사용자 세션
4. **USER_LOGINS** - 로그인 이력
5. **CATEGORIES** - 상품 카테고리
6. **BRANDS** - 브랜드 정보
7. **PRODUCTS** - 상품 정보
8. **PRODUCT_IMAGES** - 상품 이미지
9. **PRODUCT_ATTRIBUTES** - 상품 속성
10. **PRODUCT_FEATURES** - 상품 특징

### 재고 관리 테이블
11. **WAREHOUSES** - 창고 정보
12. **INVENTORY** - 재고 현황
13. **INVENTORY_MOVEMENTS** - 재고 이동 이력
14. **STOCK_ADJUSTMENTS** - 재고 조정 이력

### 주문 및 결제 테이블
15. **ORDERS** - 주문 정보
16. **ORDER_ITEMS** - 주문 상품
17. **PAYMENT_METHODS** - 결제 수단
18. **PAYMENTS** - 결제 정보
19. **PAYMENT_REFUNDS** - 환불 정보
20. **PAYMENT_RETRIES** - 결제 재시도

### 배송 관련 테이블
21. **SHIPPING_ADDRESSES** - 배송 주소
22. **SHIPPING_METHODS** - 배송 방법
23. **SHIPMENTS** - 배송 정보

### 고객 피드백 테이블
24. **REVIEWS** - 상품 리뷰
25. **REVIEW_HELPFULNESS** - 리뷰 도움도

### 마케팅 테이블
26. **PROMOTIONS** - 프로모션
27. **COUPONS** - 쿠폰
28. **WISHLISTS** - 위시리스트
29. **WISHLIST_ITEMS** - 위시리스트 상품

### 장바구니 테이블
30. **SHOPPING_CARTS** - 장바구니
31. **CART_ITEMS** - 장바구니 상품
32. **ABANDONED_CARTS** - 포기된 장바구니
33. **ABANDONED_CART_ITEMS** - 포기된 장바구니 상품

### 분석 및 추적 테이블
34. **PRODUCT_VIEWS** - 상품 조회 이력
35. **PAGE_VIEWS** - 페이지 조회 이력
36. **SEARCH_QUERIES** - 검색 쿼리 이력

### 공급업체 관리 테이블
37. **SUPPLIERS** - 공급업체
38. **PURCHASE_ORDERS** - 구매 주문
39. **PURCHASE_ORDER_ITEMS** - 구매 주문 상품

### 시스템 테이블
40. **NOTIFICATIONS** - 알림
41. **SYSTEM_LOGS** - 시스템 로그
42. **SYSTEM_CONFIGURATION** - 시스템 설정

## 복잡한 저장 프로시저 (10개)

1. **USER_MAINTENANCE_PROC** - 사용자 유지보수
2. **USER_REPORT_PROC** - 사용자 리포트 생성
3. **INVENTORY_UPDATE_PROC** - 재고 업데이트
4. **PRICE_UPDATE_PROC** - 가격 일괄 업데이트
5. **ORDER_PROCESSING_PROC** - 주문 처리
6. **PAYMENT_PROCESSING_PROC** - 결제 처리
7. **REVIEW_MODERATION_PROC** - 리뷰 검토
8. **INVENTORY_REORDER_PROC** - 재고 자동 주문
9. **ANALYTICS_REFRESH_PROC** - 분석 데이터 갱신
10. **DATA_MINING_PROC** - 데이터 마이닝

## MyBatis 매퍼별 SQL 개수

- **UserMapper**: 20개 SQL
- **ProductMapper**: 25개 SQL
- **OrderMapper**: 18개 SQL
- **PaymentMapper**: 12개 SQL
- **InventoryMapper**: 15개 SQL
- **ReviewMapper**: 12개 SQL
- **AnalyticsMapper**: 14개 SQL

**총 116개의 SQL 쿼리**

## 설치 및 실행

### 1. 데이터베이스 설정
```sql
-- Oracle 데이터베이스에 스키마 생성
@schema.sql

-- 저장 프로시저 생성
@procedures.sql
```

### 2. 애플리케이션 설정
```yaml
# application.yml 수정
spring:
  datasource:
    url: jdbc:oracle:thin:@localhost:1521:XE
    username: your_username
    password: your_password
```

### 3. 애플리케이션 실행
```bash
mvn spring-boot:run
```

## API 엔드포인트

### 사용자 관리
- `GET /api/users` - 모든 사용자 조회
- `GET /api/users/{id}` - 특정 사용자 조회
- `GET /api/users/search?keyword=` - 사용자 검색
- `POST /api/users` - 사용자 생성
- `PUT /api/users/{id}` - 사용자 수정
- `DELETE /api/users/{id}` - 사용자 삭제

### 상품 관리
- `GET /api/products` - 모든 상품 조회
- `GET /api/products/{id}` - 특정 상품 조회
- `GET /api/products/search?keyword=` - 상품 검색
- `GET /api/products/low-stock` - 재고 부족 상품
- `GET /api/products/top-selling` - 인기 상품
- `POST /api/products` - 상품 생성
- `PUT /api/products/{id}` - 상품 수정

## 마이그레이션 고려사항

### Oracle 특화 기능
1. **시퀀스 (Sequences)**: 자동 증가 ID 생성
2. **저장 프로시저**: 복잡한 비즈니스 로직
3. **Oracle 함수**: SYSDATE, TRUNC, NVL 등
4. **윈도우 함수**: ROW_NUMBER, NTILE, LAG 등
5. **계층 쿼리**: CONNECT BY (사용 시)

### 마이그레이션 시 주의점
- 데이터 타입 매핑 (NUMBER → DECIMAL/BIGINT)
- 날짜 함수 변환 (SYSDATE → NOW())
- 문자열 연결 (|| → CONCAT)
- 페이징 쿼리 (ROWNUM → LIMIT/OFFSET)
- 저장 프로시저 → 애플리케이션 로직 이전

## 성능 최적화

### 인덱스 전략
- 주요 검색 컬럼에 인덱스 생성
- 복합 인덱스 활용
- 외래키 인덱스

### 쿼리 최적화
- 적절한 조인 전략
- 서브쿼리 vs 조인 선택
- 윈도우 함수 활용

이 프로젝트는 Oracle 데이터베이스의 복잡한 기능들을 충분히 활용하여 실제 마이그레이션 시나리오를 시뮬레이션할 수 있도록 설계되었습니다.