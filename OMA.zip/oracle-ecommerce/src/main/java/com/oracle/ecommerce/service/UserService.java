package com.oracle.ecommerce.service;

import com.oracle.ecommerce.mapper.UserMapper;
import com.oracle.ecommerce.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class UserService {

    @Autowired
    private UserMapper userMapper;

    public User getUserById(Long userId) {
        return userMapper.selectById(userId);
    }

    public User getUserByUsername(String username) {
        return userMapper.selectByUsername(username);
    }

    public List<User> getAllUsers() {
        return userMapper.selectAll();
    }

    public List<User> searchUsers(String keyword) {
        return userMapper.searchUsers(keyword);
    }

    public List<Map<String, Object>> getUserStatistics() {
        return userMapper.getUserStatistics();
    }

    public int createUser(User user) {
        // 기본적인 validation
        if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
            throw new IllegalArgumentException("Username is required");
        }
        if (user.getEmail() == null || user.getEmail().trim().isEmpty()) {
            throw new IllegalArgumentException("Email is required");
        }
        if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            throw new IllegalArgumentException("Password is required");
        }
        
        // 기본값 설정
        if (user.getStatus() == null || user.getStatus().trim().isEmpty()) {
            user.setStatus("ACTIVE");
        }
        
        return userMapper.insert(user);
    }

    public int updateUser(User user) {
        return userMapper.update(user);
    }

    public int updateUserStatus(Long userId, String status) {
        return userMapper.updateStatus(userId, status);
    }

    public int deleteUser(Long userId) {
        return userMapper.delete(userId);
    }

    public void performUserMaintenance(Long userId) {
        userMapper.callUserMaintenanceProcedure(userId);
    }
}