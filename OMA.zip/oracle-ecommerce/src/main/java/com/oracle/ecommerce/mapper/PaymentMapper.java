package com.oracle.ecommerce.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Mapper
public interface PaymentMapper {
    Map<String, Object> selectById(Long paymentId);
    List<Map<String, Object>> selectByOrderId(Long orderId);
    List<Map<String, Object>> selectByUserId(Long userId);
    List<Map<String, Object>> selectByStatus(String status);
    List<Map<String, Object>> selectByPaymentMethod(String paymentMethod);
    List<Map<String, Object>> selectByDateRange(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> selectFailedPayments();
    List<Map<String, Object>> selectRefundablePayments();
    List<Map<String, Object>> getPaymentSummaryReport(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getPaymentMethodReport(@Param("startDate") String startDate, @Param("endDate") String endDate);
    int insertPayment(@Param("orderId") Long orderId, @Param("amount") BigDecimal amount, @Param("paymentMethod") String paymentMethod);
    int updatePaymentStatus(@Param("paymentId") Long paymentId, @Param("status") String status);
    int processRefund(@Param("paymentId") Long paymentId, @Param("refundAmount") BigDecimal refundAmount);
    BigDecimal getTotalPaymentsByDateRange(@Param("startDate") String startDate, @Param("endDate") String endDate);
    void callPaymentProcessingProcedure(@Param("paymentId") Long paymentId);
}