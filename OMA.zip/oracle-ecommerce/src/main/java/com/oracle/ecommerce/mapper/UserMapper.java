package com.oracle.ecommerce.mapper;

import com.oracle.ecommerce.model.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper {
    User selectById(Long userId);
    User selectByUsername(String username);
    User selectByEmail(String email);
    List<User> selectAll();
    List<User> selectByStatus(String status);
    List<User> selectActiveUsers();
    List<User> selectUsersByDateRange(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<User> selectUsersByAge(@Param("minAge") Integer minAge, @Param("maxAge") Integer maxAge);
    List<User> searchUsers(@Param("keyword") String keyword);
    List<Map<String, Object>> getUserStatistics();
    List<Map<String, Object>> getUserActivityReport(@Param("userId") Long userId);
    int insert(User user);
    int update(User user);
    int updateStatus(@Param("userId") Long userId, @Param("status") String status);
    int updatePassword(@Param("userId") Long userId, @Param("password") String password);
    int delete(Long userId);
    int batchInsert(@Param("users") List<User> users);
    int batchUpdateStatus(@Param("userIds") List<Long> userIds, @Param("status") String status);
    int countByStatus(String status);
    int countActiveUsers();
    int countUsersByDateRange(@Param("startDate") String startDate, @Param("endDate") String endDate);
    void callUserMaintenanceProcedure(@Param("userId") Long userId);
    void callUserReportProcedure(@Param("reportType") String reportType, @Param("startDate") String startDate);
}