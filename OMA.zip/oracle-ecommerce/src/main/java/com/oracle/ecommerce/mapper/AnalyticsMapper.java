package com.oracle.ecommerce.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

@Mapper
public interface AnalyticsMapper {
    List<Map<String, Object>> getDashboardMetrics();
    List<Map<String, Object>> getSalesAnalytics(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getCustomerAnalytics(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getProductPerformanceAnalytics(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getCategoryAnalytics(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getGeographicAnalytics(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getSeasonalTrends(@Param("year") Integer year);
    List<Map<String, Object>> getCustomerSegmentation();
    List<Map<String, Object>> getAbandonedCartAnalysis();
    List<Map<String, Object>> getConversionFunnelAnalysis(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getCohortAnalysis(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getRetentionAnalysis();
    void callAnalyticsRefreshProcedure(@Param("reportType") String reportType);
    void callDataMiningProcedure(@Param("algorithm") String algorithm, @Param("parameters") String parameters);
}