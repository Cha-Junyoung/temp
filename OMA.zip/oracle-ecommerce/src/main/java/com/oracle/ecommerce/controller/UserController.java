package com.oracle.ecommerce.controller;

import com.oracle.ecommerce.model.User;
import com.oracle.ecommerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        User user = userService.getUserById(id);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/search")
    public ResponseEntity<List<User>> searchUsers(@RequestParam String keyword) {
        return ResponseEntity.ok(userService.searchUsers(keyword));
    }

    @GetMapping("/statistics")
    public ResponseEntity<List<Map<String, Object>>> getUserStatistics() {
        return ResponseEntity.ok(userService.getUserStatistics());
    }

    @PostMapping
    public ResponseEntity<String> createUser(@RequestBody User user) {
        int result = userService.createUser(user);
        return result > 0 ? ResponseEntity.ok("User created successfully") : ResponseEntity.badRequest().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateUser(@PathVariable Long id, @RequestBody User user) {
        user.setUserId(id);
        int result = userService.updateUser(user);
        return result > 0 ? ResponseEntity.ok("User updated successfully") : ResponseEntity.badRequest().build();
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<String> updateUserStatus(@PathVariable Long id, @RequestParam String status) {
        int result = userService.updateUserStatus(id, status);
        return result > 0 ? ResponseEntity.ok("User status updated successfully") : ResponseEntity.badRequest().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        int result = userService.deleteUser(id);
        return result > 0 ? ResponseEntity.ok("User deleted successfully") : ResponseEntity.badRequest().build();
    }

    @PostMapping("/{id}/maintenance")
    public ResponseEntity<String> performUserMaintenance(@PathVariable Long id) {
        userService.performUserMaintenance(id);
        return ResponseEntity.ok("User maintenance completed");
    }
}