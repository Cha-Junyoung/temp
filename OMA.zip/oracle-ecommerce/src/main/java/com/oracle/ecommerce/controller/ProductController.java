package com.oracle.ecommerce.controller;

import com.oracle.ecommerce.model.Product;
import com.oracle.ecommerce.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        Product product = productService.getProductById(id);
        return product != null ? ResponseEntity.ok(product) : ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        return ResponseEntity.ok(productService.getAllProducts());
    }

    @GetMapping("/search")
    public ResponseEntity<List<Product>> searchProducts(@RequestParam String keyword) {
        return ResponseEntity.ok(productService.searchProducts(keyword));
    }

    @GetMapping("/low-stock")
    public ResponseEntity<List<Product>> getLowStockProducts() {
        return ResponseEntity.ok(productService.getLowStockProducts());
    }

    @GetMapping("/top-selling")
    public ResponseEntity<List<Product>> getTopSellingProducts(@RequestParam(defaultValue = "10") Integer limit) {
        return ResponseEntity.ok(productService.getTopSellingProducts(limit));
    }

    @GetMapping("/sales-report")
    public ResponseEntity<List<Map<String, Object>>> getProductSalesReport(
            @RequestParam String startDate, @RequestParam String endDate) {
        return ResponseEntity.ok(productService.getProductSalesReport(startDate, endDate));
    }

    @GetMapping("/inventory-report")
    public ResponseEntity<List<Map<String, Object>>> getInventoryReport() {
        return ResponseEntity.ok(productService.getInventoryReport());
    }

    @PostMapping
    public ResponseEntity<String> createProduct(@RequestBody Product product) {
        int result = productService.createProduct(product);
        return result > 0 ? ResponseEntity.ok("Product created successfully") : ResponseEntity.badRequest().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateProduct(@PathVariable Long id, @RequestBody Product product) {
        product.setProductId(id);
        int result = productService.updateProduct(product);
        return result > 0 ? ResponseEntity.ok("Product updated successfully") : ResponseEntity.badRequest().build();
    }

    @PutMapping("/{id}/stock")
    public ResponseEntity<String> updateProductStock(@PathVariable Long id, @RequestParam Integer quantity) {
        int result = productService.updateProductStock(id, quantity);
        return result > 0 ? ResponseEntity.ok("Product stock updated successfully") : ResponseEntity.badRequest().build();
    }

    @PutMapping("/{id}/price")
    public ResponseEntity<String> updateProductPrice(@PathVariable Long id, @RequestParam BigDecimal price) {
        int result = productService.updateProductPrice(id, price);
        return result > 0 ? ResponseEntity.ok("Product price updated successfully") : ResponseEntity.badRequest().build();
    }

    @PostMapping("/{id}/inventory-update")
    public ResponseEntity<String> performInventoryUpdate(@PathVariable Long id, @RequestParam Integer quantity) {
        productService.performInventoryUpdate(id, quantity);
        return ResponseEntity.ok("Inventory update completed");
    }

    @PostMapping("/category/{categoryId}/price-update")
    public ResponseEntity<String> performPriceUpdate(@PathVariable Long categoryId, @RequestParam BigDecimal percentage) {
        productService.performPriceUpdate(categoryId, percentage);
        return ResponseEntity.ok("Price update completed");
    }
}