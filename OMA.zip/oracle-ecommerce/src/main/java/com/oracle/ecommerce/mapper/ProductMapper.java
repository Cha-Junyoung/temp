package com.oracle.ecommerce.mapper;

import com.oracle.ecommerce.model.Product;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Mapper
public interface ProductMapper {
    Product selectById(Long productId);
    Product selectBySku(String sku);
    List<Product> selectAll();
    List<Product> selectByCategory(Long categoryId);
    List<Product> selectByBrand(Long brandId);
    List<Product> selectByStatus(String status);
    List<Product> selectByPriceRange(@Param("minPrice") BigDecimal minPrice, @Param("maxPrice") BigDecimal maxPrice);
    List<Product> selectLowStockProducts();
    List<Product> selectOutOfStockProducts();
    List<Product> searchProducts(@Param("keyword") String keyword);
    List<Product> selectFeaturedProducts();
    List<Product> selectNewProducts(@Param("days") Integer days);
    List<Product> selectTopSellingProducts(@Param("limit") Integer limit);
    List<Map<String, Object>> getProductSalesReport(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getInventoryReport();
    List<Map<String, Object>> getProductPerformanceReport(@Param("productId") Long productId);
    int insert(Product product);
    int update(Product product);
    int updateStock(@Param("productId") Long productId, @Param("quantity") Integer quantity);
    int updatePrice(@Param("productId") Long productId, @Param("price") BigDecimal price);
    int updateStatus(@Param("productId") Long productId, @Param("status") String status);
    int delete(Long productId);
    int batchInsert(@Param("products") List<Product> products);
    int batchUpdateStatus(@Param("productIds") List<Long> productIds, @Param("status") String status);
    int countByCategory(Long categoryId);
    int countByStatus(String status);
    int countLowStockProducts();
    void callInventoryUpdateProcedure(@Param("productId") Long productId, @Param("quantity") Integer quantity);
    void callPriceUpdateProcedure(@Param("categoryId") Long categoryId, @Param("percentage") BigDecimal percentage);
}