package com.oracle.ecommerce.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

@Mapper
public interface InventoryMapper {
    Map<String, Object> selectInventoryById(Long inventoryId);
    List<Map<String, Object>> selectInventoryByProductId(Long productId);
    List<Map<String, Object>> selectInventoryByWarehouse(Long warehouseId);
    List<Map<String, Object>> selectLowStockItems(@Param("threshold") Integer threshold);
    List<Map<String, Object>> selectOutOfStockItems();
    List<Map<String, Object>> selectOverstockItems();
    List<Map<String, Object>> selectInventoryMovements(@Param("productId") Long productId, @Param("days") Integer days);
    List<Map<String, Object>> getInventoryTurnoverReport(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getWarehouseUtilizationReport();
    List<Map<String, Object>> getStockAdjustmentHistory(@Param("startDate") String startDate, @Param("endDate") String endDate);
    int insertInventoryMovement(@Param("productId") Long productId, @Param("warehouseId") Long warehouseId, @Param("movementType") String movementType, @Param("quantity") Integer quantity);
    int updateInventoryQuantity(@Param("productId") Long productId, @Param("warehouseId") Long warehouseId, @Param("quantity") Integer quantity);
    int adjustInventory(@Param("productId") Long productId, @Param("warehouseId") Long warehouseId, @Param("adjustmentQuantity") Integer adjustmentQuantity, @Param("reason") String reason);
    int transferInventory(@Param("productId") Long productId, @Param("fromWarehouseId") Long fromWarehouseId, @Param("toWarehouseId") Long toWarehouseId, @Param("quantity") Integer quantity);
    void callInventoryReorderProcedure(@Param("warehouseId") Long warehouseId);
    void callInventoryOptimizationProcedure(@Param("categoryId") Long categoryId);
}