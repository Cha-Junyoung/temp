package com.oracle.ecommerce.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

@Mapper
public interface ReviewMapper {
    Map<String, Object> selectById(Long reviewId);
    List<Map<String, Object>> selectByProductId(Long productId);
    List<Map<String, Object>> selectByUserId(Long userId);
    List<Map<String, Object>> selectByRating(Integer rating);
    List<Map<String, Object>> selectPendingReviews();
    List<Map<String, Object>> selectRecentReviews(@Param("days") Integer days);
    List<Map<String, Object>> selectTopReviewedProducts(@Param("limit") Integer limit);
    List<Map<String, Object>> getProductRatingSummary(Long productId);
    List<Map<String, Object>> getReviewAnalytics(@Param("startDate") String startDate, @Param("endDate") String endDate);
    int insertReview(@Param("productId") Long productId, @Param("userId") Long userId, @Param("rating") Integer rating, @Param("reviewComment") String reviewComment);
    int updateReviewStatus(@Param("reviewId") Long reviewId, @Param("status") String status);
    int deleteReview(Long reviewId);
    Double getAverageRatingByProduct(Long productId);
    int getReviewCountByProduct(Long productId);
    void callReviewModerationProcedure(@Param("reviewId") Long reviewId);
}