package com.oracle.ecommerce.service;

import com.oracle.ecommerce.mapper.ProductMapper;
import com.oracle.ecommerce.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ProductService {

    @Autowired
    private ProductMapper productMapper;

    public Product getProductById(Long productId) {
        return productMapper.selectById(productId);
    }

    public List<Product> getAllProducts() {
        return productMapper.selectAll();
    }

    public List<Product> searchProducts(String keyword) {
        return productMapper.searchProducts(keyword);
    }

    public List<Product> getLowStockProducts() {
        return productMapper.selectLowStockProducts();
    }

    public List<Product> getTopSellingProducts(Integer limit) {
        return productMapper.selectTopSellingProducts(limit);
    }

    public List<Map<String, Object>> getProductSalesReport(String startDate, String endDate) {
        return productMapper.getProductSalesReport(startDate, endDate);
    }

    public List<Map<String, Object>> getInventoryReport() {
        return productMapper.getInventoryReport();
    }

    public int createProduct(Product product) {
        return productMapper.insert(product);
    }

    public int updateProduct(Product product) {
        return productMapper.update(product);
    }

    public int updateProductStock(Long productId, Integer quantity) {
        return productMapper.updateStock(productId, quantity);
    }

    public int updateProductPrice(Long productId, BigDecimal price) {
        return productMapper.updatePrice(productId, price);
    }

    public void performInventoryUpdate(Long productId, Integer quantity) {
        productMapper.callInventoryUpdateProcedure(productId, quantity);
    }

    public void performPriceUpdate(Long categoryId, BigDecimal percentage) {
        productMapper.callPriceUpdateProcedure(categoryId, percentage);
    }
}