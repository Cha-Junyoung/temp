package com.oracle.ecommerce.service;

import com.oracle.ecommerce.mapper.ProductMapper;
import com.oracle.ecommerce.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ProductService {

    @Autowired
    private ProductMapper productMapper;

    public Product getProductById(Long productId) {
        return productMapper.selectById(productId);
    }

    public List<Product> getAllProducts() {
        return productMapper.selectAll();
    }

    public List<Product> searchProducts(String keyword) {
        return productMapper.searchProducts(keyword);
    }

    public List<Product> getLowStockProducts() {
        return productMapper.selectLowStockProducts();
    }

    public List<Product> getTopSellingProducts(Integer limit) {
        return productMapper.selectTopSellingProducts(limit);
    }

    public List<Map<String, Object>> getProductSalesReport(String startDate, String endDate) {
        return productMapper.getProductSalesReport(startDate, endDate);
    }

    public List<Map<String, Object>> getInventoryReport() {
        return productMapper.getInventoryReport();
    }

    public int createProduct(Product product) {
        // 기본적인 validation
        if (product.getProductName() == null || product.getProductName().trim().isEmpty()) {
            throw new IllegalArgumentException("Product name is required");
        }
        if (product.getPrice() == null || product.getPrice().doubleValue() < 0) {
            throw new IllegalArgumentException("Price must be non-negative");
        }
        if (product.getStockQuantity() != null && product.getStockQuantity() < 0) {
            throw new IllegalArgumentException("Stock quantity must be non-negative");
        }
        
        // 기본값 설정
        if (product.getStatus() == null || product.getStatus().trim().isEmpty()) {
            product.setStatus("ACTIVE");
        }
        
        return productMapper.insert(product);
    }

    public int updateProduct(Product product) {
        return productMapper.update(product);
    }

    public int updateProductStock(Long productId, Integer quantity) {
        return productMapper.updateStock(productId, quantity);
    }

    public int updateProductPrice(Long productId, BigDecimal price) {
        return productMapper.updatePrice(productId, price);
    }

    public void performInventoryUpdate(Long productId, Integer quantity) {
        productMapper.callInventoryUpdateProcedure(productId, quantity);
    }

    public void performPriceUpdate(Long categoryId, BigDecimal percentage) {
        productMapper.callPriceUpdateProcedure(categoryId, percentage);
    }
}