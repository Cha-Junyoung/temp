package com.oracle.ecommerce.mapper;

import com.oracle.ecommerce.model.Order;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Mapper
public interface OrderMapper {
    Order selectById(Long orderId);
    Order selectByOrderNumber(String orderNumber);
    List<Order> selectAll();
    List<Order> selectByUserId(Long userId);
    List<Order> selectByStatus(String orderStatus);
    List<Order> selectByDateRange(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Order> selectPendingOrders();
    List<Order> selectRecentOrders(@Param("days") Integer days);
    List<Order> selectOrdersByAmountRange(@Param("minAmount") BigDecimal minAmount, @Param("maxAmount") BigDecimal maxAmount);
    List<Map<String, Object>> getOrderSummaryReport(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getDailySalesReport(@Param("startDate") String startDate, @Param("endDate") String endDate);
    List<Map<String, Object>> getCustomerOrderHistory(@Param("userId") Long userId);
    List<Map<String, Object>> getTopCustomersByOrders(@Param("limit") Integer limit);
    int insert(Order order);
    int update(Order order);
    int updateStatus(@Param("orderId") Long orderId, @Param("status") String status);
    int updatePaymentStatus(@Param("orderId") Long orderId, @Param("paymentStatus") String paymentStatus);
    int updateShippingStatus(@Param("orderId") Long orderId, @Param("shippingStatus") String shippingStatus);
    int delete(Long orderId);
    int countByStatus(String status);
    int countByUserId(Long userId);
    BigDecimal getTotalSalesByDateRange(@Param("startDate") String startDate, @Param("endDate") String endDate);
    void callOrderProcessingProcedure(@Param("orderId") Long orderId);
    void callOrderReportProcedure(@Param("reportType") String reportType, @Param("startDate") String startDate, @Param("endDate") String endDate);
}