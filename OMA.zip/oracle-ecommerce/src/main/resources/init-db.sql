-- =================================================================================
-- Oracle E-commerce Project: FINAL & COMPLETE Sample Data Insertion Script (v4 - Enriched)
-- Description: Truncates ALL tables and dynamically populates them with a rich, non-null dataset.
-- =================================================================================

-- Section 0: Initialize Database by Deleting All Existing Data
-- ---------------------------------------------------------------------------------
PROMPT Deleting all existing data from tables...

-- Disable foreign key constraints to allow deletion
BEGIN
    FOR c IN (SELECT table_name, constraint_name FROM user_constraints WHERE constraint_type = 'R') LOOP
        EXECUTE IMMEDIATE 'ALTER TABLE ' || c.table_name || ' DISABLE CONSTRAINT ' || c.constraint_name;
    END LOOP;
END;
/

-- Truncate all tables for a clean slate
BEGIN
    FOR t IN (SELECT table_name FROM user_tables WHERE table_name NOT LIKE 'SYS%' AND table_name NOT LIKE '%$') LOOP
        EXECUTE IMMEDIATE 'TRUNCATE TABLE ' || t.table_name;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('All tables have been truncated.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('An error occurred during TRUNCATE: ' || SQLERRM || '. This might be okay if tables were already empty.');
END;
/

-- Re-enable foreign key constraints
BEGIN
    FOR c IN (SELECT table_name, constraint_name FROM user_constraints WHERE constraint_type = 'R') LOOP
        EXECUTE IMMEDIATE 'ALTER TABLE ' || c.table_name || ' ENABLE CONSTRAINT ' || c.constraint_name;
    END LOOP;
END;
/

PROMPT Database has been reset.

-- =================================================================================
-- Section 1: Dynamic Bulk Data Generation for ALL Tables with Rich Data
-- =================================================================================
PROMPT Starting bulk data generation for all tables...

DECLARE
    v_user_count      CONSTANT NUMBER := 100;
    v_product_count   CONSTANT NUMBER := 200;
    v_order_count     CONSTANT NUMBER := 500;
    
    v_order_id        NUMBER;
    v_order_total     NUMBER;
    v_items_in_order  NUMBER;
    v_random_user_id  NUMBER;
    v_random_product_id NUMBER;
    v_unit_price      NUMBER;
    v_quantity        NUMBER;
    v_order_status    VARCHAR2(20);
    v_payment_status  VARCHAR2(20);
    v_shipping_status VARCHAR2(20);
    v_order_date      TIMESTAMP;
    v_gender          CHAR(1);

BEGIN
    -- === Base Master Data ===
    INSERT INTO CATEGORIES (CATEGORY_ID, CATEGORY_NAME, DESCRIPTION) VALUES (1, 'Electronics', 'Gadgets and electronic devices');
    INSERT INTO CATEGORIES (CATEGORY_ID, CATEGORY_NAME, DESCRIPTION) VALUES (2, 'Books', 'Fiction and non-fiction books');
    INSERT INTO BRANDS (BRAND_ID, BRAND_NAME, DESCRIPTION) VALUES (1, 'TechCorp', 'Leading manufacturer of electronic goods.');
    INSERT INTO BRANDS (BRAND_ID, BRAND_NAME, DESCRIPTION) VALUES (2, 'InnovateInc', 'Innovative and modern tech solutions.');
    INSERT INTO WAREHOUSES (WAREHOUSE_ID, WAREHOUSE_NAME, LOCATION) VALUES (1, 'Main Warehouse', 'Seoul');
    INSERT INTO PAYMENT_METHODS (METHOD_ID, METHOD_NAME, PROVIDER) VALUES (1, 'Credit Card', 'Visa/Mastercard');
    INSERT INTO SHIPPING_METHODS (METHOD_ID, METHOD_NAME, DESCRIPTION, BASE_COST, ESTIMATED_DAYS) VALUES (1, 'Standard Shipping', '3-5 business days', 3.00, 3);
    INSERT INTO SUPPLIERS (SUPPLIER_ID, SUPPLIER_NAME, CONTACT_PERSON, EMAIL) VALUES (1, 'Global Electronics Parts', 'Mr. Kim', 'sales@globalelectronics.com');
    INSERT INTO PROMOTIONS (PROMOTION_ID, PROMOTION_NAME, DESCRIPTION, PROMOTION_TYPE, DISCOUNT_TYPE, DISCOUNT_VALUE, START_DATE, END_DATE, STATUS) VALUES (1, 'Summer Sale', 'Annual summer discount event', 'SITE_WIDE', 'PERCENTAGE', 15, SYSDATE - 10, SYSDATE + 20, 'ACTIVE');
    INSERT INTO SYSTEM_CONFIGURATION (CONFIG_ID, CONFIG_KEY, CONFIG_VALUE, DESCRIPTION) VALUES (1, 'SITE_NAME', 'My E-Commerce', 'The public name of the website.');

    -- === Generate Users and ALL related entities with rich data ===
    FOR i IN 1..v_user_count LOOP
        IF i = 1 THEN
            v_gender := 'M';
            INSERT INTO USERS (USER_ID, USERNAME, EMAIL, PASSWORD, FIRST_NAME, LAST_NAME, PHONE_NUMBER, BIRTH_DATE, GENDER, STATUS) 
            VALUES (1, 'admin', 'admin@example.com', 'admin_pass', 'Admin', 'User', '010-0000-0001', TO_DATE('1980-01-01', 'YYYY-MM-DD'), v_gender, 'ACTIVE');
        ELSE
            IF MOD(i, 2) = 0 THEN v_gender := 'F'; ELSE v_gender := 'M'; END IF;
            INSERT INTO USERS (USER_ID, USERNAME, EMAIL, PASSWORD, FIRST_NAME, LAST_NAME, PHONE_NUMBER, BIRTH_DATE, GENDER, STATUS) 
            VALUES (i, 'user' || i, 'user' || i || '@example.com', 'pass_' || i, 'User', 'Name' || i, 
                    '010-' || LPAD(TRUNC(DBMS_RANDOM.VALUE(1000, 10000)), 4, '0') || '-' || LPAD(TRUNC(DBMS_RANDOM.VALUE(1000, 10000)), 4, '0'),
                    TO_DATE('1970-01-01', 'YYYY-MM-DD') + TRUNC(DBMS_RANDOM.VALUE(0, 365*35)),
                    v_gender, 'ACTIVE');
        END IF;
        
        INSERT INTO USER_PROFILES (PROFILE_ID, USER_ID, BIO, PREFERENCES) VALUES (i, i, 'A sample biography for user ' || i || '. This user enjoys shopping for new and exciting products.', '{"theme":"dark", "language":"en"}');
        INSERT INTO SHIPPING_ADDRESSES (ADDRESS_ID, USER_ID, FIRST_NAME, LAST_NAME, ADDRESS_LINE1, CITY, POSTAL_CODE, COUNTRY, IS_DEFAULT) VALUES (i, i, 'User', 'Name' || i, i || ' Teheran-ro, Gangnam-gu', 'Seoul', '0123' || MOD(i, 10), 'South Korea', 'Y');
        INSERT INTO WISHLISTS (WISHLIST_ID, USER_ID, WISHLIST_NAME) VALUES (i, i, 'My Wishlist ' || i);
        INSERT INTO COUPONS (COUPON_ID, COUPON_CODE, PROMOTION_ID, USER_ID, STATUS) VALUES (i, 'WELCOME' || i, 1, i, 'ACTIVE');
    END LOOP;

    -- === Generate Products and related entities with rich data ===
    FOR i IN 1..v_product_count LOOP
        INSERT INTO PRODUCTS (PRODUCT_ID, PRODUCT_NAME, DESCRIPTION, SKU, CATEGORY_ID, BRAND_ID, PRICE, STOCK_QUANTITY, WEIGHT, DIMENSIONS) 
        VALUES (100 + i, 'Premium Product ' || i, 'This is a high-quality sample product description for item ' || i || '. It has excellent features and a modern design.', 
                'SKU' || LPAD(100 + i, 6, '0'), MOD(i, 2) + 1, MOD(i, 2) + 1, ROUND(DBMS_RANDOM.VALUE(10, 2000), 2), TRUNC(DBMS_RANDOM.VALUE(50, 500)), 
                ROUND(DBMS_RANDOM.VALUE(0.1, 5), 2), '10x20x5 cm');
        INSERT INTO INVENTORY (INVENTORY_ID, PRODUCT_ID, WAREHOUSE_ID, QUANTITY) VALUES (500 + i, 100 + i, 1, (SELECT STOCK_QUANTITY FROM PRODUCTS WHERE PRODUCT_ID = 100 + i));
        INSERT INTO PRODUCT_IMAGES (IMAGE_ID, PRODUCT_ID, IMAGE_URL, ALT_TEXT, IS_PRIMARY) VALUES (200 + i, 100 + i, 'http://example.com/product' || i || '.jpg', 'Image of Product ' || i, 'Y');
        INSERT INTO PRODUCT_ATTRIBUTES (ATTRIBUTE_ID, PRODUCT_ID, ATTRIBUTE_NAME, ATTRIBUTE_VALUE) VALUES (300 + i, 100 + i, 'Color', CASE MOD(i,3) WHEN 0 THEN 'Black' WHEN 1 THEN 'White' ELSE 'Silver' END);
    END LOOP;

    -- === Generate Orders and ALL related transactional entities ===
    FOR i IN 1..v_order_count LOOP
        v_order_id       := 2000 + i;
        v_order_total    := 0;
        v_items_in_order := TRUNC(DBMS_RANDOM.VALUE(1, 4));
        v_random_user_id := TRUNC(DBMS_RANDOM.VALUE(1, v_user_count + 1));
        v_order_date     := SYSTIMESTAMP - DBMS_RANDOM.VALUE(1, 730);

        CASE TRUNC(DBMS_RANDOM.VALUE(1, 6))
            WHEN 1 THEN v_order_status := 'COMPLETED'; v_payment_status := 'PAID'; v_shipping_status := 'DELIVERED';
            WHEN 2 THEN v_order_status := 'SHIPPED';   v_payment_status := 'PAID'; v_shipping_status := 'SHIPPED';
            WHEN 3 THEN v_order_status := 'PROCESSING';v_payment_status := 'PAID'; v_shipping_status := 'PREPARING';
            WHEN 4 THEN v_order_status := 'PENDING';   v_payment_status := 'PENDING'; v_shipping_status := 'NOT_SHIPPED';
            WHEN 5 THEN v_order_status := 'RETURNED';  v_payment_status := 'REFUNDED'; v_shipping_status := 'RETURNED';
        END CASE;

        INSERT INTO ORDERS (ORDER_ID, ORDER_NUMBER, USER_ID, ORDER_STATUS, TOTAL_AMOUNT, FINAL_AMOUNT, PAYMENT_STATUS, SHIPPING_STATUS, ORDER_DATE, NOTES)
        VALUES (v_order_id, 'ORD' || LPAD(v_order_id, 8, '0'), v_random_user_id, v_order_status, 0, 0, v_payment_status, v_shipping_status, v_order_date, 'Customer note for order ' || v_order_id);

        FOR j IN 1..v_items_in_order LOOP
            v_random_product_id := TRUNC(DBMS_RANDOM.VALUE(1, v_product_count + 1)) + 100;
            v_quantity          := TRUNC(DBMS_RANDOM.VALUE(1, 3));
            SELECT PRICE INTO v_unit_price FROM PRODUCTS WHERE PRODUCT_ID = v_random_product_id;
            INSERT INTO ORDER_ITEMS (ORDER_ITEM_ID, ORDER_ID, PRODUCT_ID, QUANTITY, UNIT_PRICE, TOTAL_PRICE)
            VALUES ( (v_order_count * 4) + (i*4) + j, v_order_id, v_random_product_id, v_quantity, v_unit_price, (v_unit_price * v_quantity));
            v_order_total := v_order_total + (v_unit_price * v_quantity);
        END LOOP;
        
        UPDATE ORDERS SET TOTAL_AMOUNT = v_order_total, FINAL_AMOUNT = v_order_total + 3 WHERE ORDER_ID = v_order_id;
        
        INSERT INTO PAYMENTS (PAYMENT_ID, ORDER_ID, AMOUNT, PAYMENT_METHOD_ID, PAYMENT_STATUS, TRANSACTION_ID)
        VALUES (2000 + i, v_order_id, v_order_total + 3, 1, v_payment_status, 'txn_' || DBMS_RANDOM.STRING('X', 12));
        
        IF v_payment_status = 'REFUNDED' THEN
            INSERT INTO PAYMENT_REFUNDS(REFUND_ID, PAYMENT_ID, REFUND_AMOUNT, REFUND_STATUS, REFUND_REASON) VALUES (3000+i, 2000+i, v_order_total + 3, 'COMPLETED', 'Item returned');
        ELSIF v_payment_status = 'PENDING' THEN
            INSERT INTO PAYMENT_RETRIES(RETRY_ID, PAYMENT_ID, RETRY_COUNT, FAILURE_REASON) VALUES (4000+i, 2000+i, 1, 'Insufficient funds');
        END IF;

        IF v_shipping_status NOT IN ('NOT_SHIPPED', 'PREPARING') THEN
             INSERT INTO SHIPMENTS (SHIPMENT_ID, ORDER_ID, SHIPPING_METHOD_ID, TRACKING_NUMBER, CARRIER, STATUS)
             VALUES (5000 + i, v_order_id, 1, 'TRK' || DBMS_RANDOM.STRING('X', 10), 'CJ Logistics', v_shipping_status);
             INSERT INTO INVENTORY_MOVEMENTS(MOVEMENT_ID, PRODUCT_ID, WAREHOUSE_ID, MOVEMENT_TYPE, QUANTITY, REFERENCE_TYPE, REFERENCE_ID)
             VALUES(6000+i, v_random_product_id, 1, 'SALE', -v_quantity, 'ORDER', v_order_id);
        END IF;
    END LOOP;

    -- === Generate Interaction and Log Data ===
    FOR i IN 1..v_user_count LOOP
        v_random_product_id := TRUNC(DBMS_RANDOM.VALUE(1, v_product_count + 1)) + 100;
        INSERT INTO USER_LOGINS(LOGIN_ID, USER_ID, LOGIN_STATUS, IP_ADDRESS) VALUES(100+i, i, 'SUCCESS', '192.168.1.' || i);
        INSERT INTO REVIEWS(REVIEW_ID, PRODUCT_ID, USER_ID, RATING, REVIEW_COMMENT, STATUS) VALUES (7000 + i, v_random_product_id, i, TRUNC(DBMS_RANDOM.VALUE(3, 6)), 'This is a detailed and well-written sample review for product ' || v_random_product_id, 'APPROVED');
        INSERT INTO WISHLIST_ITEMS (WISHLIST_ITEM_ID, WISHLIST_ID, PRODUCT_ID) VALUES (8000 + i, i, v_random_product_id);
        INSERT INTO SHOPPING_CARTS(CART_ID, USER_ID, STATUS) VALUES(9000+i, i, 'ACTIVE');
        INSERT INTO CART_ITEMS(CART_ITEM_ID, CART_ID, PRODUCT_ID, QUANTITY) VALUES(10000+i, 9000+i, v_random_product_id, 1);
        INSERT INTO NOTIFICATIONS(NOTIFICATION_ID, USER_ID, NOTIFICATION_TYPE, TITLE, MESSAGE) VALUES(11000+i, i, 'WELCOME', 'Welcome!', 'Thank you for joining our community.');
        INSERT INTO SYSTEM_LOGS(LOG_ID, LOG_LEVEL, LOG_MESSAGE, USER_ID) VALUES(12000+i, 'INFO', 'User ' || i || ' logged in successfully.', i);
        INSERT INTO PRODUCT_VIEWS(VIEW_ID, PRODUCT_ID, USER_ID, IP_ADDRESS) VALUES(13000+i, v_random_product_id, i, '192.168.1.' || i);
        INSERT INTO PAGE_VIEWS(VIEW_ID, PAGE_URL, PAGE_TITLE, IP_ADDRESS) VALUES(14000+i, '/home', 'Homepage', '192.168.1.' || i);
        INSERT INTO SEARCH_QUERIES(QUERY_ID, USER_ID, QUERY_TEXT, RESULTS_COUNT) VALUES(15000+i, i, 'premium product', 5);
        INSERT INTO REVIEW_HELPFULNESS(HELPFULNESS_ID, REVIEW_ID, USER_ID, IS_HELPFUL) VALUES(16000+i, 7000+i, MOD(i, v_user_count)+1, 'Y');
        INSERT INTO PURCHASE_ORDERS(PO_ID, PO_NUMBER, SUPPLIER_ID, STATUS, TOTAL_AMOUNT) VALUES(17000+i, 'PO'||(17000+i), 1, 'COMPLETED', 500);
        INSERT INTO PURCHASE_ORDER_ITEMS(PO_ITEM_ID, PO_ID, PRODUCT_ID, QUANTITY, UNIT_COST, TOTAL_COST) VALUES(18000+i, 17000+i, v_random_product_id, 50, 10, 500);
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('Bulk data generation finished.');
END;
/

COMMIT;

-- =================================================================================
-- Section 2: Reset Sequences After Bulk Insertion
-- =================================================================================
PROMPT Resetting all sequences...

DECLARE
  PROCEDURE reset_sequence(p_seq_name IN VARCHAR2, p_table_name IN VARCHAR2, p_col_name IN VARCHAR2) IS
    l_max_val NUMBER;
  BEGIN
    EXECUTE IMMEDIATE 'SELECT NVL(MAX(' || p_col_name || '), 0) + 1 FROM ' || p_table_name INTO l_max_val;
    EXECUTE IMMEDIATE 'DROP SEQUENCE ' || p_seq_name;
    EXECUTE IMMEDIATE 'CREATE SEQUENCE ' || p_seq_name || ' START WITH ' || l_max_val || ' INCREMENT BY 1';
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Could not reset ' || p_seq_name || '. Error: ' || SQLERRM);
  END;
BEGIN
  reset_sequence('USER_SEQ', 'USERS', 'USER_ID');
  reset_sequence('PRODUCT_SEQ', 'PRODUCTS', 'PRODUCT_ID');
  reset_sequence('ORDER_SEQ', 'ORDERS', 'ORDER_ID');
  reset_sequence('PAYMENT_SEQ', 'PAYMENTS', 'PAYMENT_ID');
  reset_sequence('INVENTORY_SEQ', 'INVENTORY', 'INVENTORY_ID');
  reset_sequence('REVIEW_SEQ', 'REVIEWS', 'REVIEW_ID');
  reset_sequence('CATEGORY_SEQ', 'CATEGORIES', 'CATEGORY_ID');
  reset_sequence('BRAND_SEQ', 'BRANDS', 'BRAND_ID');
  reset_sequence('WAREHOUSE_SEQ', 'WAREHOUSES', 'WAREHOUSE_ID');
  reset_sequence('PROMOTION_SEQ', 'PROMOTIONS', 'PROMOTION_ID');
  reset_sequence('COUPON_SEQ', 'COUPONS', 'COUPON_ID');
  reset_sequence('SHIPPING_SEQ', 'SHIPMENTS', 'SHIPMENT_ID');
  reset_sequence('REFUND_SEQ', 'PAYMENT_REFUNDS', 'REFUND_ID');
  reset_sequence('INVENTORY_MOVEMENT_SEQ', 'INVENTORY_MOVEMENTS', 'MOVEMENT_ID');
  reset_sequence('STOCK_ADJUSTMENT_SEQ', 'STOCK_ADJUSTMENTS', 'ADJUSTMENT_ID');
  reset_sequence('NOTIFICATION_SEQ', 'NOTIFICATIONS', 'NOTIFICATION_ID');
  reset_sequence('SYSTEM_LOG_SEQ', 'SYSTEM_LOGS', 'LOG_ID');
  reset_sequence('PURCHASE_ORDER_SEQ', 'PURCHASE_ORDERS', 'PO_ID');
  reset_sequence('PO_ITEM_SEQ', 'PURCHASE_ORDER_ITEMS', 'PO_ITEM_ID');
  reset_sequence('RECOMMENDATION_SEQ', 'PRODUCT_RECOMMENDATIONS', 'RECOMMENDATION_ID');
  
  DBMS_OUTPUT.PUT_LINE('All sequences have been reset successfully.');
END;
/

PROMPT Script finished successfully.