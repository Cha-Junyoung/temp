-- Complex Oracle Stored Procedures for E-commerce System

-- 1. User Maintenance Procedure
CREATE OR REPLACE PROCEDURE USER_MAINTENANCE_PROC(p_user_id IN NUMBER)
IS
    v_order_count NUMBER;
    v_last_login DATE;
    v_status VARCHAR2(20);
BEGIN
    -- Get user statistics
    SELECT COUNT(*), MAX(ul.LOGIN_TIME)
    INTO v_order_count, v_last_login
    FROM ORDERS o
    RIGHT JOIN USER_LOGINS ul ON o.USER_ID = ul.USER_ID
    WHERE o.USER_ID = p_user_id OR ul.USER_ID = p_user_id;
    
    -- Determine user status based on activity
    IF v_last_login < SYSDATE - 365 THEN
        v_status := 'INACTIVE';
    ELSIF v_order_count = 0 AND v_last_login < SYSDATE - 90 THEN
        v_status := 'INACTIVE';
    ELSE
        v_status := 'ACTIVE';
    END IF;
    
    -- Update user status
    UPDATE USERS 
    SET STATUS = v_status, UPDATED_AT = SYSDATE 
    WHERE USER_ID = p_user_id;
    
    -- Clean up old sessions
    DELETE FROM USER_SESSIONS 
    WHERE USER_ID = p_user_id 
    AND LAST_ACCESS_TIME < SYSDATE - 30;
    
    -- Archive old notifications
    UPDATE NOTIFICATIONS 
    SET IS_READ = 'Y' 
    WHERE USER_ID = p_user_id 
    AND CREATED_AT < SYSDATE - 90 
    AND IS_READ = 'N';
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END USER_MAINTENANCE_PROC;
/

-- 2. User Report Procedure
CREATE OR REPLACE PROCEDURE USER_REPORT_PROC(
    p_report_type IN VARCHAR2,
    p_start_date IN VARCHAR2
)
IS
    v_start_date DATE;
    v_end_date DATE;
    CURSOR c_user_stats IS
        SELECT 
            u.USER_ID,
            u.USERNAME,
            u.EMAIL,
            COUNT(DISTINCT o.ORDER_ID) as ORDER_COUNT,
            NVL(SUM(o.FINAL_AMOUNT), 0) as TOTAL_SPENT,
            MAX(o.ORDER_DATE) as LAST_ORDER_DATE
        FROM USERS u
        LEFT JOIN ORDERS o ON u.USER_ID = o.USER_ID 
        AND o.ORDER_STATUS = 'COMPLETED'
        AND o.ORDER_DATE BETWEEN v_start_date AND v_end_date
        WHERE u.STATUS = 'ACTIVE'
        GROUP BY u.USER_ID, u.USERNAME, u.EMAIL
        ORDER BY TOTAL_SPENT DESC;
BEGIN
    v_start_date := TO_DATE(p_start_date, 'YYYY-MM-DD');
    v_end_date := SYSDATE;
    
    -- Create temporary report table if not exists
    BEGIN
        EXECUTE IMMEDIATE 'DROP TABLE TEMP_USER_REPORT';
    EXCEPTION
        WHEN OTHERS THEN NULL;
    END;
    
    EXECUTE IMMEDIATE 'CREATE GLOBAL TEMPORARY TABLE TEMP_USER_REPORT (
        USER_ID NUMBER,
        USERNAME VARCHAR2(50),
        EMAIL VARCHAR2(100),
        ORDER_COUNT NUMBER,
        TOTAL_SPENT NUMBER(10,2),
        LAST_ORDER_DATE DATE,
        REPORT_TYPE VARCHAR2(50),
        GENERATED_AT TIMESTAMP
    ) ON COMMIT PRESERVE ROWS';
    
    -- Insert report data using Dynamic SQL
    FOR rec IN c_user_stats LOOP
        EXECUTE IMMEDIATE 'INSERT INTO TEMP_USER_REPORT VALUES (:1, :2, :3, :4, :5, :6, :7, :8)'
        USING rec.USER_ID, rec.USERNAME, rec.EMAIL, rec.ORDER_COUNT, 
              rec.TOTAL_SPENT, rec.LAST_ORDER_DATE, p_report_type, SYSDATE;
    END LOOP;
    
    COMMIT;
END USER_REPORT_PROC;
/

-- 3. Inventory Update Procedure
CREATE OR REPLACE PROCEDURE INVENTORY_UPDATE_PROC(
    p_product_id IN NUMBER,
    p_quantity IN NUMBER
)
IS
    v_current_stock NUMBER;
    v_min_stock NUMBER;
    v_max_stock NUMBER;
    v_warehouse_id NUMBER;
    v_movement_type VARCHAR2(50);
BEGIN
    -- Get current stock levels
    SELECT STOCK_QUANTITY, MIN_STOCK_LEVEL, MAX_STOCK_LEVEL
    INTO v_current_stock, v_min_stock, v_max_stock
    FROM PRODUCTS
    WHERE PRODUCT_ID = p_product_id;
    
    -- Determine movement type
    IF p_quantity > 0 THEN
        v_movement_type := 'STOCK_IN';
    ELSE
        v_movement_type := 'STOCK_OUT';
    END IF;
    
    -- Update product stock
    UPDATE PRODUCTS 
    SET STOCK_QUANTITY = STOCK_QUANTITY + p_quantity,
        UPDATED_AT = SYSDATE
    WHERE PRODUCT_ID = p_product_id;
    
    -- Get primary warehouse
    SELECT MIN(WAREHOUSE_ID) INTO v_warehouse_id FROM WAREHOUSES WHERE STATUS = 'ACTIVE';
    
    -- Update inventory table
    MERGE INTO INVENTORY i
    USING (SELECT p_product_id as PRODUCT_ID, v_warehouse_id as WAREHOUSE_ID FROM DUAL) src
    ON (i.PRODUCT_ID = src.PRODUCT_ID AND i.WAREHOUSE_ID = src.WAREHOUSE_ID)
    WHEN MATCHED THEN
        UPDATE SET QUANTITY = QUANTITY + p_quantity, UPDATED_AT = SYSDATE
    WHEN NOT MATCHED THEN
        INSERT (INVENTORY_ID, PRODUCT_ID, WAREHOUSE_ID, QUANTITY, CREATED_AT)
        VALUES (INVENTORY_SEQ.NEXTVAL, p_product_id, v_warehouse_id, p_quantity, SYSDATE);
    
    -- Log inventory movement
    INSERT INTO INVENTORY_MOVEMENTS (
        MOVEMENT_ID, PRODUCT_ID, WAREHOUSE_ID, MOVEMENT_TYPE, QUANTITY,
        REFERENCE_TYPE, CREATED_AT, CREATED_BY
    ) VALUES (
        INVENTORY_MOVEMENT_SEQ.NEXTVAL, p_product_id, v_warehouse_id, v_movement_type, p_quantity,
        'MANUAL_ADJUSTMENT', SYSDATE, 1
    );
    
    -- Check for low stock alert
    IF (v_current_stock + p_quantity) <= v_min_stock THEN
        INSERT INTO NOTIFICATIONS (
            NOTIFICATION_ID, USER_ID, NOTIFICATION_TYPE, TITLE, MESSAGE, CREATED_AT
        ) VALUES (
            NOTIFICATION_SEQ.NEXTVAL, 1, 'LOW_STOCK_ALERT', 'Low Stock Alert',
            'Product ID ' || p_product_id || ' is running low on stock. Current: ' || (v_current_stock + p_quantity),
            SYSDATE
        );
    END IF;
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END INVENTORY_UPDATE_PROC;
/

-- 4. Price Update Procedure
CREATE OR REPLACE PROCEDURE PRICE_UPDATE_PROC(
    p_category_id IN NUMBER,
    p_percentage IN NUMBER
)
IS
    v_count NUMBER := 0;
    CURSOR c_products IS
        SELECT PRODUCT_ID, PRICE, PRODUCT_NAME
        FROM PRODUCTS
        WHERE CATEGORY_ID = p_category_id
        AND STATUS = 'ACTIVE';
BEGIN
    -- Update prices for all products in category
    FOR rec IN c_products LOOP
        UPDATE PRODUCTS 
        SET PRICE = PRICE * (1 + p_percentage / 100),
            UPDATED_AT = SYSDATE
        WHERE PRODUCT_ID = rec.PRODUCT_ID;
        
        -- Log price change
        INSERT INTO SYSTEM_LOGS (
            LOG_ID, LOG_LEVEL, LOG_MESSAGE, LOG_SOURCE, CREATED_AT
        ) VALUES (
            SYSTEM_LOG_SEQ.NEXTVAL, 'INFO',
            'Price updated for product ' || rec.PRODUCT_NAME || ' (ID: ' || rec.PRODUCT_ID || ') by ' || p_percentage || '%',
            'PRICE_UPDATE_PROC', SYSDATE
        );
        
        v_count := v_count + 1;
    END LOOP;
    
    -- Create notification for admin
    INSERT INTO NOTIFICATIONS (
        NOTIFICATION_ID, USER_ID, NOTIFICATION_TYPE, TITLE, MESSAGE, CREATED_AT
    ) VALUES (
        NOTIFICATION_SEQ.NEXTVAL, 1, 'PRICE_UPDATE', 'Bulk Price Update Completed',
        'Updated prices for ' || v_count || ' products in category ' || p_category_id || ' by ' || p_percentage || '%',
        SYSDATE
    );
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END PRICE_UPDATE_PROC;
/

-- 5. Order Processing Procedure
CREATE OR REPLACE PROCEDURE ORDER_PROCESSING_PROC(p_order_id IN NUMBER)
IS
    v_order_status VARCHAR2(20);
    v_payment_status VARCHAR2(20);
    v_user_id NUMBER;
    v_total_amount NUMBER;
    CURSOR c_order_items IS
        SELECT oi.PRODUCT_ID, oi.QUANTITY, p.STOCK_QUANTITY
        FROM ORDER_ITEMS oi
        JOIN PRODUCTS p ON oi.PRODUCT_ID = p.PRODUCT_ID
        WHERE oi.ORDER_ID = p_order_id;
BEGIN
    -- Get order details
    SELECT ORDER_STATUS, PAYMENT_STATUS, USER_ID, FINAL_AMOUNT
    INTO v_order_status, v_payment_status, v_user_id, v_total_amount
    FROM ORDERS
    WHERE ORDER_ID = p_order_id;
    
    -- Process only if order is pending and payment is completed
    IF v_order_status = 'PENDING' AND v_payment_status = 'PAID' THEN
        
        -- Check stock availability
        FOR rec IN c_order_items LOOP
            IF rec.STOCK_QUANTITY < rec.QUANTITY THEN
                RAISE_APPLICATION_ERROR(-20001, 'Insufficient stock for product ID: ' || rec.PRODUCT_ID);
            END IF;
        END LOOP;
        
        -- Reserve inventory
        FOR rec IN c_order_items LOOP
            UPDATE PRODUCTS 
            SET STOCK_QUANTITY = STOCK_QUANTITY - rec.QUANTITY
            WHERE PRODUCT_ID = rec.PRODUCT_ID;
            
            -- Log inventory movement
            INSERT INTO INVENTORY_MOVEMENTS (
                MOVEMENT_ID, PRODUCT_ID, WAREHOUSE_ID, MOVEMENT_TYPE, QUANTITY,
                REFERENCE_TYPE, REFERENCE_ID, CREATED_AT
            ) VALUES (
                INVENTORY_MOVEMENT_SEQ.NEXTVAL, rec.PRODUCT_ID, 1, 'SALE', -rec.QUANTITY,
                'ORDER', p_order_id, SYSDATE
            );
        END LOOP;
        
        -- Update order status
        UPDATE ORDERS 
        SET ORDER_STATUS = 'PROCESSING',
            UPDATED_AT = SYSDATE
        WHERE ORDER_ID = p_order_id;
        
        -- Create shipment record
        INSERT INTO SHIPMENTS (
            SHIPMENT_ID, ORDER_ID, SHIPPING_METHOD_ID, STATUS, CREATED_AT
        ) VALUES (
            SHIPPING_SEQ.NEXTVAL, p_order_id, 1, 'PREPARING', SYSDATE
        );
        
        -- Send notification to customer
        INSERT INTO NOTIFICATIONS (
            NOTIFICATION_ID, USER_ID, NOTIFICATION_TYPE, TITLE, MESSAGE, CREATED_AT
        ) VALUES (
            NOTIFICATION_SEQ.NEXTVAL, v_user_id, 'ORDER_PROCESSING', 'Order Being Processed',
            'Your order #' || p_order_id || ' is now being processed for shipment.',
            SYSDATE
        );
        
    END IF;
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END ORDER_PROCESSING_PROC;
/

-- 6. Payment Processing Procedure
CREATE OR REPLACE PROCEDURE PAYMENT_PROCESSING_PROC(p_payment_id IN NUMBER)
IS
    v_payment_status VARCHAR2(20);
    v_order_id NUMBER;
    v_amount NUMBER;
    v_user_id NUMBER;
BEGIN
    -- Get payment details
    SELECT p.PAYMENT_STATUS, p.ORDER_ID, p.AMOUNT, o.USER_ID
    INTO v_payment_status, v_order_id, v_amount, v_user_id
    FROM PAYMENTS p
    JOIN ORDERS o ON p.ORDER_ID = o.ORDER_ID
    WHERE p.PAYMENT_ID = p_payment_id;
    
    -- Process payment if pending
    IF v_payment_status = 'PENDING' THEN
        
        -- Simulate payment gateway processing
        -- In real implementation, this would call external payment gateway
        
        -- Update payment status
        UPDATE PAYMENTS 
        SET PAYMENT_STATUS = 'COMPLETED',
            PROCESSED_AT = SYSDATE,
            UPDATED_AT = SYSDATE
        WHERE PAYMENT_ID = p_payment_id;
        
        -- Update order payment status
        UPDATE ORDERS 
        SET PAYMENT_STATUS = 'PAID',
            UPDATED_AT = SYSDATE
        WHERE ORDER_ID = v_order_id;
        
        -- Send confirmation notification
        INSERT INTO NOTIFICATIONS (
            NOTIFICATION_ID, USER_ID, NOTIFICATION_TYPE, TITLE, MESSAGE, CREATED_AT
        ) VALUES (
            NOTIFICATION_SEQ.NEXTVAL, v_user_id, 'PAYMENT_CONFIRMED', 'Payment Confirmed',
            'Your payment of $' || v_amount || ' for order #' || v_order_id || ' has been confirmed.',
            SYSDATE
        );
        
        -- Trigger order processing
        ORDER_PROCESSING_PROC(v_order_id);
        
    END IF;
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END PAYMENT_PROCESSING_PROC;
/

-- 7. Review Moderation Procedure
CREATE OR REPLACE PROCEDURE REVIEW_MODERATION_PROC(p_review_id IN NUMBER)
IS
    v_rating NUMBER;
    v_comment CLOB;
    v_user_id NUMBER;
    v_product_id NUMBER;
    v_status VARCHAR2(20);
    v_word_count NUMBER;
BEGIN
    -- Get review details
    SELECT RATING, REVIEW_COMMENT, USER_ID, PRODUCT_ID
    INTO v_rating, v_comment, v_user_id, v_product_id
    FROM REVIEWS
    WHERE REVIEW_ID = p_review_id;
    
    -- Auto-moderation logic
    v_word_count := LENGTH(v_comment) - LENGTH(REPLACE(v_comment, ' ', '')) + 1;
    
    IF v_rating >= 4 AND v_word_count >= 10 THEN
        v_status := 'APPROVED';
    ELSIF v_rating <= 2 AND v_word_count < 5 THEN
        v_status := 'REJECTED';
    ELSIF UPPER(v_comment) LIKE '%SPAM%' OR UPPER(v_comment) LIKE '%FAKE%' THEN
        v_status := 'REJECTED';
    ELSE
        v_status := 'PENDING'; -- Requires manual review
    END IF;
    
    -- Update review status
    UPDATE REVIEWS 
    SET STATUS = v_status,
        MODERATED_AT = SYSDATE,
        UPDATED_AT = SYSDATE
    WHERE REVIEW_ID = p_review_id;
    
    -- If approved, update product rating cache
    IF v_status = 'APPROVED' THEN
        UPDATE PRODUCTS 
        SET UPDATED_AT = SYSDATE
        WHERE PRODUCT_ID = v_product_id;
        
        -- Send notification to user
        INSERT INTO NOTIFICATIONS (
            NOTIFICATION_ID, USER_ID, NOTIFICATION_TYPE, TITLE, MESSAGE, CREATED_AT
        ) VALUES (
            NOTIFICATION_SEQ.NEXTVAL, v_user_id, 'REVIEW_APPROVED', 'Review Approved',
            'Your review for product ID ' || v_product_id || ' has been approved and is now visible.',
            SYSDATE
        );
    END IF;
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END REVIEW_MODERATION_PROC;
/

-- 8. Inventory Reorder Procedure
CREATE OR REPLACE PROCEDURE INVENTORY_REORDER_PROC(p_warehouse_id IN NUMBER)
IS
    CURSOR c_low_stock IS
        SELECT p.PRODUCT_ID, p.PRODUCT_NAME, p.SKU, i.QUANTITY, p.MIN_STOCK_LEVEL, p.MAX_STOCK_LEVEL,
               s.SUPPLIER_ID, s.SUPPLIER_NAME
        FROM PRODUCTS p
        JOIN INVENTORY i ON p.PRODUCT_ID = i.PRODUCT_ID
        LEFT JOIN SUPPLIERS s ON p.BRAND_ID = s.SUPPLIER_ID -- Simplified relationship
        WHERE i.WAREHOUSE_ID = p_warehouse_id
        AND i.QUANTITY <= p.MIN_STOCK_LEVEL
        AND p.STATUS = 'ACTIVE';
    
    v_po_id NUMBER;
    v_po_number VARCHAR2(50);
    v_reorder_quantity NUMBER;
BEGIN
    FOR rec IN c_low_stock LOOP
        -- Calculate reorder quantity
        v_reorder_quantity := rec.MAX_STOCK_LEVEL - rec.QUANTITY;
        
        -- Create purchase order if supplier exists
        IF rec.SUPPLIER_ID IS NOT NULL THEN
            -- Generate PO number
            SELECT 'PO' || TO_CHAR(SYSDATE, 'YYYYMMDD') || LPAD(PURCHASE_ORDER_SEQ.NEXTVAL, 6, '0')
            INTO v_po_number FROM DUAL;
            
            -- Create purchase order
            INSERT INTO PURCHASE_ORDERS (
                PO_ID, PO_NUMBER, SUPPLIER_ID, STATUS, ORDER_DATE, CREATED_AT
            ) VALUES (
                PURCHASE_ORDER_SEQ.CURRVAL, v_po_number, rec.SUPPLIER_ID, 'PENDING', SYSDATE, SYSDATE
            ) RETURNING PO_ID INTO v_po_id;
            
            -- Add purchase order item
            INSERT INTO PURCHASE_ORDER_ITEMS (
                PO_ITEM_ID, PO_ID, PRODUCT_ID, QUANTITY, UNIT_COST, TOTAL_COST, CREATED_AT
            ) VALUES (
                PO_ITEM_SEQ.NEXTVAL, v_po_id, rec.PRODUCT_ID, v_reorder_quantity, 
                0, 0, SYSDATE -- Cost to be updated by procurement team
            );
            
            -- Log the reorder
            INSERT INTO SYSTEM_LOGS (
                LOG_ID, LOG_LEVEL, LOG_MESSAGE, LOG_SOURCE, CREATED_AT
            ) VALUES (
                SYSTEM_LOG_SEQ.NEXTVAL, 'INFO',
                'Auto-reorder created for product ' || rec.PRODUCT_NAME || ' (SKU: ' || rec.SKU || ') - Quantity: ' || v_reorder_quantity,
                'INVENTORY_REORDER_PROC', SYSDATE
            );
        END IF;
        
        -- Create low stock notification
        INSERT INTO NOTIFICATIONS (
            NOTIFICATION_ID, USER_ID, NOTIFICATION_TYPE, TITLE, MESSAGE, CREATED_AT
        ) VALUES (
            NOTIFICATION_SEQ.NEXTVAL, 1, 'LOW_STOCK_ALERT', 'Low Stock Alert',
            'Product ' || rec.PRODUCT_NAME || ' (SKU: ' || rec.SKU || ') is low on stock. Current: ' || rec.QUANTITY || ', Min: ' || rec.MIN_STOCK_LEVEL,
            SYSDATE
        );
    END LOOP;
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END INVENTORY_REORDER_PROC;
/

-- 9. Analytics Refresh Procedure
CREATE OR REPLACE PROCEDURE ANALYTICS_REFRESH_PROC(p_report_type IN VARCHAR2)
IS
    v_start_time TIMESTAMP;
    v_end_time TIMESTAMP;
BEGIN
    v_start_time := SYSTIMESTAMP;
    
    -- Refresh different analytics based on report type
    CASE p_report_type
        WHEN 'DAILY_SALES' THEN
            -- Refresh daily sales analytics
            MERGE INTO DAILY_SALES_ANALYTICS dst
            USING (
                SELECT 
                    TRUNC(ORDER_DATE) as SALES_DATE,
                    COUNT(*) as ORDER_COUNT,
                    SUM(FINAL_AMOUNT) as TOTAL_SALES,
                    AVG(FINAL_AMOUNT) as AVG_ORDER_VALUE
                FROM ORDERS
                WHERE ORDER_STATUS = 'COMPLETED'
                AND ORDER_DATE >= TRUNC(SYSDATE) - 7
                GROUP BY TRUNC(ORDER_DATE)
            ) src ON (dst.SALES_DATE = src.SALES_DATE)
            WHEN MATCHED THEN
                UPDATE SET 
                    ORDER_COUNT = src.ORDER_COUNT,
                    TOTAL_SALES = src.TOTAL_SALES,
                    AVG_ORDER_VALUE = src.AVG_ORDER_VALUE,
                    UPDATED_AT = SYSDATE
            WHEN NOT MATCHED THEN
                INSERT (SALES_DATE, ORDER_COUNT, TOTAL_SALES, AVG_ORDER_VALUE, CREATED_AT)
                VALUES (src.SALES_DATE, src.ORDER_COUNT, src.TOTAL_SALES, src.AVG_ORDER_VALUE, SYSDATE);
                
        WHEN 'PRODUCT_PERFORMANCE' THEN
            -- Refresh product performance analytics
            MERGE INTO PRODUCT_PERFORMANCE_ANALYTICS dst
            USING (
                SELECT 
                    p.PRODUCT_ID,
                    COUNT(oi.ORDER_ITEM_ID) as ORDER_COUNT,
                    SUM(oi.QUANTITY) as TOTAL_SOLD,
                    SUM(oi.TOTAL_PRICE) as TOTAL_REVENUE
                FROM PRODUCTS p
                LEFT JOIN ORDER_ITEMS oi ON p.PRODUCT_ID = oi.PRODUCT_ID
                LEFT JOIN ORDERS o ON oi.ORDER_ID = o.ORDER_ID
                WHERE o.ORDER_STATUS = 'COMPLETED'
                AND o.ORDER_DATE >= TRUNC(SYSDATE) - 30
                GROUP BY p.PRODUCT_ID
            ) src ON (dst.PRODUCT_ID = src.PRODUCT_ID)
            WHEN MATCHED THEN
                UPDATE SET 
                    ORDER_COUNT = src.ORDER_COUNT,
                    TOTAL_SOLD = src.TOTAL_SOLD,
                    TOTAL_REVENUE = src.TOTAL_REVENUE,
                    UPDATED_AT = SYSDATE
            WHEN NOT MATCHED THEN
                INSERT (PRODUCT_ID, ORDER_COUNT, TOTAL_SOLD, TOTAL_REVENUE, CREATED_AT)
                VALUES (src.PRODUCT_ID, src.ORDER_COUNT, src.TOTAL_SOLD, src.TOTAL_REVENUE, SYSDATE);
                
        ELSE
            -- Default: refresh all analytics
            ANALYTICS_REFRESH_PROC('DAILY_SALES');
            ANALYTICS_REFRESH_PROC('PRODUCT_PERFORMANCE');
    END CASE;
    
    v_end_time := SYSTIMESTAMP;
    
    -- Log the refresh operation
    INSERT INTO SYSTEM_LOGS (
        LOG_ID, LOG_LEVEL, LOG_MESSAGE, LOG_SOURCE, CREATED_AT
    ) VALUES (
        SYSTEM_LOG_SEQ.NEXTVAL, 'INFO',
        'Analytics refresh completed for ' || p_report_type || ' in ' || 
        EXTRACT(SECOND FROM (v_end_time - v_start_time)) || ' seconds',
        'ANALYTICS_REFRESH_PROC', SYSDATE
    );
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END ANALYTICS_REFRESH_PROC;
/

-- 10. Data Mining Procedure
CREATE OR REPLACE PROCEDURE DATA_MINING_PROC(
    p_algorithm IN VARCHAR2,
    p_parameters IN VARCHAR2
)
IS
    v_result_count NUMBER := 0;
BEGIN
    -- Implement different data mining algorithms
    CASE p_algorithm
        WHEN 'CUSTOMER_SEGMENTATION' THEN
            -- RFM Analysis (Recency, Frequency, Monetary)
            INSERT INTO CUSTOMER_SEGMENTS (
                USER_ID, SEGMENT_TYPE, RECENCY_SCORE, FREQUENCY_SCORE, MONETARY_SCORE, CREATED_AT
            )
            SELECT 
                u.USER_ID,
                CASE 
                    WHEN rfm.R_SCORE >= 4 AND rfm.F_SCORE >= 4 AND rfm.M_SCORE >= 4 THEN 'CHAMPIONS'
                    WHEN rfm.R_SCORE >= 3 AND rfm.F_SCORE >= 3 AND rfm.M_SCORE >= 3 THEN 'LOYAL_CUSTOMERS'
                    WHEN rfm.R_SCORE >= 3 AND rfm.F_SCORE <= 2 THEN 'POTENTIAL_LOYALISTS'
                    WHEN rfm.R_SCORE <= 2 AND rfm.F_SCORE >= 3 THEN 'AT_RISK'
                    ELSE 'OTHERS'
                END as SEGMENT_TYPE,
                rfm.R_SCORE, rfm.F_SCORE, rfm.M_SCORE, SYSDATE
            FROM USERS u
            JOIN (
                SELECT 
                    o.USER_ID,
                    NTILE(5) OVER (ORDER BY MAX(o.ORDER_DATE) DESC) as R_SCORE,
                    NTILE(5) OVER (ORDER BY COUNT(o.ORDER_ID)) as F_SCORE,
                    NTILE(5) OVER (ORDER BY SUM(o.FINAL_AMOUNT)) as M_SCORE
                FROM ORDERS o
                WHERE o.ORDER_STATUS = 'COMPLETED'
                GROUP BY o.USER_ID
            ) rfm ON u.USER_ID = rfm.USER_ID;
            
            v_result_count := SQL%ROWCOUNT;
            
        WHEN 'PRODUCT_RECOMMENDATION' THEN
            -- Collaborative filtering for product recommendations
            INSERT INTO PRODUCT_RECOMMENDATIONS (
                USER_ID, PRODUCT_ID, RECOMMENDATION_SCORE, ALGORITHM_TYPE, CREATED_AT
            )
            SELECT DISTINCT
                u.USER_ID,
                oi2.PRODUCT_ID,
                COUNT(*) as RECOMMENDATION_SCORE,
                'COLLABORATIVE_FILTERING',
                SYSDATE
            FROM USERS u
            JOIN ORDERS o1 ON u.USER_ID = o1.USER_ID
            JOIN ORDER_ITEMS oi1 ON o1.ORDER_ID = oi1.ORDER_ID
            JOIN ORDER_ITEMS oi2 ON oi1.PRODUCT_ID != oi2.PRODUCT_ID
            JOIN ORDERS o2 ON oi2.ORDER_ID = o2.ORDER_ID
            WHERE o1.ORDER_STATUS = 'COMPLETED'
            AND o2.ORDER_STATUS = 'COMPLETED'
            AND NOT EXISTS (
                SELECT 1 FROM ORDER_ITEMS oi3
                JOIN ORDERS o3 ON oi3.ORDER_ID = o3.ORDER_ID
                WHERE o3.USER_ID = u.USER_ID
                AND oi3.PRODUCT_ID = oi2.PRODUCT_ID
                AND o3.ORDER_STATUS = 'COMPLETED'
            )
            GROUP BY u.USER_ID, oi2.PRODUCT_ID
            HAVING COUNT(*) >= 2;
            
            v_result_count := SQL%ROWCOUNT;
            
        ELSE
            RAISE_APPLICATION_ERROR(-20002, 'Unknown algorithm: ' || p_algorithm);
    END CASE;
    
    -- Log the data mining operation
    INSERT INTO SYSTEM_LOGS (
        LOG_ID, LOG_LEVEL, LOG_MESSAGE, LOG_SOURCE, CREATED_AT
    ) VALUES (
        SYSTEM_LOG_SEQ.NEXTVAL, 'INFO',
        'Data mining completed for algorithm ' || p_algorithm || '. Results: ' || v_result_count || ' records processed.',
        'DATA_MINING_PROC', SYSDATE
    );
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END DATA_MINING_PROC;
/